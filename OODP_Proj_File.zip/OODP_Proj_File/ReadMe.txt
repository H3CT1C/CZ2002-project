This is Group 8's submission for CZ2002 Group Project.

Prerequisites to run the program:
--------------------------------------
1. Any recent version of java, java8 and above.
2. Maven to build the project.

Instructions to run the program:
--------------------------------------
1. Enter the working directory for the project, the same directory where the pom.xml file is located.
2. run the command: mvn exec:java

Misc
-------------------------------------
To access the student portal,
Below is the login details for a student with access period from :
username: UserN0010
password: dummypass0010

The access period for the above user is granted until 20th December 2020, 10AM as of submission time. This access period can be
changed via the program.

To access the admin portal,
Below is the login details for an admin with "SCSE" privileges.
username: AdminN0001
password: dummypass0001

Available schools to select from are "SCSE", "MAE", "EEE".
Available courses and groups to select from each school can be explored via the admin panel.
Data will persist across different executions of the program. For example, if we change the password of a user and close the application, 
the password to be entered should be what we changed it into during the program runtime.