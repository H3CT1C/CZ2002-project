package cz2002;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class WaitList implements StudentQueue, NotificationInterface {

    private String courseID;
    private String groupID;
    private LinkedList<Student> studentQueue;
    


    public WaitList(String courseID, String groupID, LinkedList<Student> studentQueue) {
        this.courseID = courseID;
        this.groupID = groupID;
        this.studentQueue = studentQueue;
    }

    public WaitList(String courseID, String groupID) {
        this.courseID = courseID;
        this.groupID = groupID;
        studentQueue = new LinkedList<>();
    }
    
	/**
	 * removes students by checking the student ID of each student object in the studentQueue by comparing it to the studentID passed
	 *
	 *@param studentID the Student ID that needs to be matched
	 *
	 *@return Student the Student Object with the same studentID as the string passed in that was removed
	 */

    @Override
    public Student removeStudentByID(String studentID) {
        for (int i=0; i<studentQueue.size(); i++) {
            Student student = studentQueue.get(i);
            if (student.getUID().equalsIgnoreCase(studentID)) {
                studentQueue.remove(i);
                return student;
            }
        }
        return null;
    }   
    
	/**
	 * removes the first student if the queue is not null and calls upon the notifyStudentRemove method to send an email to inform the student
	 *
	 *@return Student the student object that was removed
	 */

    @Override
    public Student removeHead() {
        if (studentQueue.isEmpty())
            return null;
        Student student = studentQueue.removeFirst();
        notifyStudentRemove(student);
        return student;
    }
    
	/**
	 * Adds the student object passed into the first slot of the studentQueueand notifies the student via the notifyStudentAdd method
	 *
	 *@param student, the student object that is to be inserted into the list
	 *
	 */

    @Override
    public void addHead(Student student) {
        studentQueue.addFirst(student);
        notifyStudentAdd(student);
    }
    
	/**
	 * takes in a student object and sends an email through the EmailService class specifically about being added to the Waitlist
	 *
	 *@param student the student object an email is to be sent to
	 */

    @Override
    public void notifyStudentAdd(Student student) {
        String title = String.format("Notification for adding to wait list for %s %s", courseID, groupID);
        String message = String.format(
        "Dear %s, \n" +
        "This is a confirmation email that you have been added into the wait list for %s %s. \n" +
        "You will be notified as soon as you are enrolled succesfully. \n" +
        "Thank you. This is an automated email, do not reply.", student.getFirstName(), this.courseID, this.groupID);
        EmailService.sendMail(student.getEmail(), title, message);
    }
    
	/**
	 * takes in a student object and sends an email through the EmailService class specifically about being removed from the Waitlist
	 *
	 *@param student the student object an email is to be sent to
	 */

    @Override
    public void notifyStudentRemove(Student student) {
        String title = String.format("Notification for removal from wait list for %s %s", courseID, groupID);
        String message = String.format(
        "Dear %s, \n" +
        "This is a confirmation email that you have been removed into the wait list for %s %s. \n" +
        "Thank you. This is an automated email, do not reply.", student.getFirstName(), this.courseID, this.groupID);
        EmailService.sendMail(student.getEmail(), title, message);
    }

    
    @Override
    public int getSize() {
        return studentQueue.size();
    }
    
	/**
	 *returns the all the student info in the LinkedList as a string
	 *
	 *@return String returns a string containing the infomation of all students formatted in a way that can be printed easily
	 */

    @Override
    public String toString() {
        StringBuilder displayString = new StringBuilder();
        displayString.append("Below are a list of the information of the students in the wait list: \n");
        for (int i=0; i<studentQueue.size(); i++) {
            displayString.append(studentQueue.get(i).toString() + "\n");
        }
        return displayString.toString();
    }
    
	/**
	 * returns the student info but in the form of a List
	 *
	 *@return List an ArrayList containing all the student objects in studentQueue
	 */

    public List<Student> getAllStudents() {
        List<Student> studs = new ArrayList<>();
        for (int i=0; i<studentQueue.size(); i++) {
            studs.add(studentQueue.get(i));
        }
        return studs;
    }

}
