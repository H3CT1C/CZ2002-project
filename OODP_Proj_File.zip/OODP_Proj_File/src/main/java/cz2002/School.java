package cz2002;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


// school keeps track of courses within itself
public class School {
    
    private String schoolName;
    private Map<String, Course> courses;

    public School(String schoolName, Map<String,Course> courses) {
        this.schoolName = schoolName;
        this.courses = courses;
    }

    public School(String schoolName) {
        this.schoolName = schoolName;
        courses = new HashMap<>();
    }

    // constructor
    public School() {
        System.out.println("--- - Creating a new school ----");
        System.out.println("Enter the school's name: ");
        this.schoolName = IO.nextLine();
        this.courses = new HashMap<>();
    }

    public String getSchoolName() {
        return schoolName;
    }
    
    /**
	 *returns a turns all the appropriate attributes of a school into a string and returns it
	 *
     *@return String a string containing all the info of a school
	 */

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("School: " + schoolName + "\n");
        sb.append("Courses are as follows: " + "\n");
        for (String s: courses.keySet()) {
            sb.append(s + "\n");
        }
        return sb.toString();
    }
    
    /**
	 * turns a HashMap of Courses into a list of Courses
	 * 
     * @return a list containing all the courses in a school
	 */

    public List<Course> getAllCourses() {
        List<Course> courseList = new ArrayList<>();
        for (Course course: courses.values()) {
            courseList.add(course);
        }
        return courseList;
    }
    
    /**
	 *Asks for the name of a new course and compares it to all the courses currently in a school. If it is unique, it is added and addtional information is asked for, before the new course is added to the list of courses for the school
	 * 
	 * @return course object being added, null if fail
	 */
    public Course addACourse() {
        System.out.println("Enter course id to add: ");
        String courseID = IO.nextLine();
        // check if has write access to a school
        if (courses.containsKey(courseID)) {
            System.out.println("Failed to add this course! It already exists.");
        } else {
            // creating a course
            System.out.println("Enter name of the course: ");
            String courseName = IO.nextLine();
            System.out.println("Enter the number of AU for the course (1-5)");
            int au = IO.nextInt(1, 5);
            Course courseToAdd = new Course(courseID, courseName, au, schoolName);
            courses.put(courseToAdd.getCourseID(), courseToAdd); // append to list of courses
            System.out.printf("Course: %s added successfully to %s. \n", courseToAdd.getCourseName(), schoolName);
            return courseToAdd;
        }
        return null;
    }
    
    /**
	 *Asks for a courseID to be removed, and compares it to all the courses in a school. If it exists, it is removed
	 * 
	 */
    public void removeACourse() {
        System.out.println("Enter course id to remove: ");
        String courseID = IO.nextLine();
        if (courses.containsKey(courseID)) {
            courses.remove(courseID);
            System.out.printf("Course: %s removed successfully! \n", courseID);
        } else {
            System.out.printf("Course: %s does not exist in %s! \n", courseID, schoolName);
        }
    }
    
    /**
	 *Takes in a String and compares it to the Courses in the School. If a course is found, the Course object is returned
	 * 
     *@param courseID the Course ID to search for
     *
     *@return the course that matches the Course ID sent in
	 */
    public Course findACourse(String courseID) {
        Course courseFound = null;
        if (courses.containsKey(courseID)) {
            courseFound = courses.get(courseID);
            System.out.printf("Retrieved Course %s successfully! \n", courseID);
        } else {
            System.out.printf("Course: %s does not exist in %s! \n", courseID, schoolName);
        }
        
        return courseFound;
    }
    
}
