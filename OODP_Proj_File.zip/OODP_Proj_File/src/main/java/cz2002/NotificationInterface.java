package cz2002;

public interface NotificationInterface {
    public void notifyStudentAdd(Student student);
    public void notifyStudentRemove(Student student);
}
