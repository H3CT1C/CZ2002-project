package cz2002;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * Admin class inheriting from user
 */
public class Admin extends User{

	private final String studentDataFilePath = "StudentData.txt";

	public Admin(String firstName, String lastName, String UID, String username, String password, String email, String gender, String nationality, String school, boolean adminStatus) {
		super(firstName, lastName, UID, username, password, email, gender, nationality, school, adminStatus);
	}

	/**
	 * Returns a string wih user's info formatted for display
	 * 
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(" -- - Admin details -- - \n");
		sb.append("Admin ID: " + this.getUID() + "\n");
		sb.append("First name: " + this.getFirstName() + "\n");
		sb.append("Last name: " + this.getLastName() + "\n");
		sb.append("Email: " + this.getEmail() + "\n");
		sb.append("Gender: " + this.getGender() + "\n");
		sb.append("Nationality: " + this.getNationality() + "\n");
		sb.append("School: " + this.getSchool() + "\n");
		return sb.toString();
	}

	/**
	 * Adds and saves the student object into the file for data to persist
	 * assumes a valid student has been passed in, error checking is done outside of the class
	 * 
	 * @param student Student object to be saved
	 * 
	 * @throws IOException if failed to read a file
	 * 
	 */
	public void addStudent(Student student) throws IOException {
		StringBuilder sb = new StringBuilder();
		try(BufferedReader br = new BufferedReader(new FileReader(studentDataFilePath))) {
            String line = br.readLine();
            while (line != null) {
                sb.append(line + "\n");
                line = br.readLine();
            }
		}
		sb.append(student.toSaveString());
		try {
			FileWriter f2 = new FileWriter(studentDataFilePath, false);
			f2.write(sb.toString());
			f2.close();
		
		} catch (IOException e) {
			e.printStackTrace();
		}   
	}

}
