package cz2002;

import java.util.*;

// controls the logic for coordination between waitlist and student list
/**
 * Entity class for a group object
 * Controls the logic for coordination between its wait list and student list
 */
public class Group {
    private String courseID;
    private String groupID;
    private EnrolledList studentList;
    private WaitList waitList;
    private int slots;
    private Timetable timetable;
    private String schoolName;

    /**
     * Constructor for group entity class, with predefined entity attributes
     * 
     * @param courseID id the course the group belongs to
     * @param groupID id of the group
     * @param schoolName school name the group belongs to
     * @param studentList the enrolled list object the group has a reference to
     * @param waitList the wait list object the group has a reference to
     * @param slots the number of slots for the group
     * @param timetable the timetable object for the group
     * 
     */
    public Group(String courseID, String groupID, String schoolName, EnrolledList studentList, WaitList waitList, int slots, Timetable timetable) {
        this.courseID = courseID.trim();
        this.groupID = groupID.trim();
        this.schoolName = schoolName.trim();
        this.studentList = studentList;
        this.waitList = waitList;
        this.slots = slots;
        this.timetable = timetable;
    }

    /**
     * A secondary constructor for the group
     * 
     * @param courseID course id the group belongs to
     * @param groupID id of the group
     * @param schoolName school name the group belongs to
     * @param mappedTimetable a mapped representation of the details for each activity in each week
     * 
     */
    public Group(String courseID, String groupID, String schoolName, Map<String, Map<String, String>> mappedTimetable) {
        this.courseID = courseID.trim();
        this.groupID = groupID.trim();
        this.schoolName = schoolName.trim();

        System.out.printf("--- - Creating new group %s --- - \n", groupID);
        System.out.println("Enter group vacancy: ");
        this.slots = IO.nextInt();

        this.timetable = new Timetable(groupID, courseID, mappedTimetable);

        this.studentList = new EnrolledList(courseID, groupID);
        this.waitList = new WaitList(courseID, groupID); 
    }

    // Function to attempt to add a student into the group
    public void enrollStudent(Student student, int au) {
        if (getVacancies() > 0) {
            student.setAU(student.getAU() + au);
            List<Group> groupsEnrolled = student.getGroups();
            groupsEnrolled.add(this);
            student.setGroups(groupsEnrolled);
            this.studentList.addStudent(student);
            System.out.println("Successfully enrolled! A confirmation email should be sent shortly.");
        } else {
            System.out.printf("Failed to add student into %s %s. \n", this.courseID, this.groupID);
            System.out.printf("There is no more vacancy for %s %s. \n", this.courseID, this.groupID);
            System.out.println("Would you like to be enrolled into the wait list (y/n)? ");
            char reply = IO.getYesOrNo();
            if (reply == 'y') {
                student.setAU(student.getAU() + au);
                List<Group> groupsWaitList = student.getWaitlists();
                groupsWaitList.add(this);
                student.setWaitLists(groupsWaitList);
                this.waitList.addHead(student);
                System.out.println("Added you to the wait list successfully! You will be notified via email when you are successfully enrolled.");
            }
        }
    }

    public Timetable getTimetable() {
        return this.timetable;
    }

    /**
     * Function to uneroll a student, also handles updation of waitlist and vacancy accordingly
     * @param studentID id of the student to unenroll
     * @param fromEnrolled y or n char to denote whether to unenroll from the enrolled list or student list
     */
    public void unenrollStudent(String studentID, char fromEnrolled) {
        if (fromEnrolled == 'y') {
            Student foundStudent = this.studentList.removeStudentByID(studentID);
            System.out.println("You have unenrolled successfully! A confirmation email will be sent shortly.");
            if (foundStudent != null) { // found the student
                Student studentFirstInWaitlist = this.waitList.removeHead();
                if (studentFirstInWaitlist != null) {
                    this.studentList.addStudent(studentFirstInWaitlist);
                    List<Group> updateWaitList = studentFirstInWaitlist.getWaitlists();
                    List<Group> grps = studentFirstInWaitlist.getGroups();
                    
                    Iterator<Group> it = updateWaitList.iterator();
                    while (it.hasNext()) {
                        Group g = it.next();
                        if (g.getGroupID().equalsIgnoreCase(groupID) && g.getCourseID().equalsIgnoreCase(courseID)) {
                            updateWaitList.remove(g);
                            grps.add(g);
                        }
                    }
                    studentFirstInWaitlist.setWaitLists(updateWaitList);
                    studentFirstInWaitlist.setGroups(grps);
                }
                    
            } else {
                System.out.printf("Student is not enrolled in %s %s! \n", this.courseID, this.groupID);
            }
        }
        else {
            removeStudentFromWaitList(studentID);
        }
    }

    /**
     * Removes a student from the wait list via the student id
     * @param studentID the id of the student
     * 
     */
    public void removeStudentFromWaitList(String studentID) {
        this.waitList.removeStudentByID(studentID);
    }

    /**
     * Displays the information of the students enrolled
     * 
     * @return a string representation of the enrolled student list
     * 
     */
    public String displayStudentsEnrolled() {
        String result = String.format("Displaying information of students enrolled in %s %s. \n", this.courseID, this.groupID);
        result += this.studentList.toString() + "\n";
        return result;
    }

    /**
     * Displays the information of students in wait list
     * 
     * @return a string representation of the wait list
     * 
     */
    public String displayStudentsInWaitList() {
        String result = String.format("Displaying information of students in %s %s waitlist. \n", this.courseID, this.groupID);
        result += this.waitList.toString() + "\n";
        return result;
    }

    /**
     * Displays the timetable
     * 
     * @return a string representation of the timetable
     * 
     */
    public String displayGroupTimetable() {
        String result = String.format("Displaying timetable for %s %s. \n", this.courseID, this.groupID);
        result += this.timetable.toString() + "\n";
        return result;
    }

    public String getGroupID(){
        return groupID;
    }
    
    public void setGroupID(String indexID){
        this.groupID = indexID;
    }
    
    public String getCourseID(){
        return courseID;
    }
    
    public void setCourseID(String courseID) {
        setCourseID(courseID);
    }

    public List<Student> getStudentsEnrolled(){
        return studentList.getAllStudents();
    }

    public int getSlots(){
        // return number of slots in a group
        return slots;
    }
    
    public void setSlots(int newSlots){
        // change slot number
        if (newSlots >= studentList.getSize())
            this.slots = newSlots;
        else
            System.out.println("Cannot reduce slot more then the number of students enrolled.");
    }

    public int getVacancies() {
        return this.slots - studentList.getSize();
    }

    public EnrolledList getEnrolledList() {
        return this.studentList;
    }

    public void setEnrolledList(EnrolledList studentsEnrolled) {
        this.studentList = studentsEnrolled;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(" -- - Displaying information for %s %s %s -- - \n", schoolName, courseID, groupID));
        sb.append("Number of slots: " + this.slots + "\n");
        sb.append("Number of vacancies: " + getVacancies() + "\n");
        sb.append(displayStudentsEnrolled());
        sb.append(displayStudentsInWaitList());
        sb.append(displayGroupTimetable());
        sb.append("\n");
        return sb.toString();
    }

    public String toSaveString() {
        StringBuilder sb = new StringBuilder();
        sb.append("--" + groupID + "\n");
        sb.append("StudentsEnrolled: ");
        for (Student s: studentList.getAllStudents()) {
            sb.append(s.getUID() + " ");
        }
        sb.append(" \n");
        sb.append("StudentsInWaitList: ");
        for (Student s: waitList.getAllStudents()) {
            sb.append(s.getUID() + " ");
        }
        sb.append(" \n");
        sb.append("slots: " + slots + "\n");
        sb.append(timetable.toSaveString());
        return sb.toString();
    }
}
