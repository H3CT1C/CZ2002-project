package cz2002;

import java.util.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.io.Console;

// helper class to handle input, output operations, formatting or translating for common operations
public class IO {
    private static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyy HH:mm");
    private static Scanner scanner = new Scanner(System.in);
    
    /**
	 *Tries to scan for an Integer. If an Integer is not found, the method gets called again
	 * 
     *@return returns the number that is inputted
	 */

    public static int nextInt() {
    	int val;
        while(true) {
        	try {
            	val = scanner.nextInt();
            	scanner.nextLine();
                return val;
            }
            catch(Exception e) {
            	System.out.println("Please Enter only Numbers!");
            	scanner.nextLine();
            	return IO.nextInt();
            }
        }
    }
    
    /**
	 *Overloading nextInt,except that it also checks that the number is in between the lower and upper
	 * 
     *@param lower the lower limit of the integer to be input
     *@param upper the upper limit of the integer to be input
     *
     *@return returns an integer that is in between the lower and upper, inclusive
     *
	 */
    public static int nextInt(int lower, int upper) {
        int val = lower - 1;
        boolean ok = false;
        while(!ok) {
        	try {
            	val = IO.nextInt();
                while(val < lower || val > upper) {
                    System.out.println("Invalid Value entered!");
                    val = IO.nextInt();
                } 
                ok = true;
            }
            catch(Exception e) {
                System.out.println("Please Enter only Numbers!");
                IO.nextLine();
            }
        }
        return val;
    }
    
    /**
	 * Prompts the user for a date time in a specific format. If it does not match the format, it gets rejected. returns the date time input
	 * 
     *@return LocalDateTime returns the LocalDateTime that the user inputs
	 */

    public static LocalDateTime promptUserLocalDateTime() {
        System.out.println("Enter date (DD-MM-YYYY HH:mm): ");
        while (true) {
            try {
                String stringInput = scanner.nextLine();
                LocalDateTime input = LocalDateTime.parse(stringInput, formatter);
                LocalDateTime today = LocalDateTime.now(ZoneId.of("Asia/Singapore"));
                // ensure only future time is selected
                if (input.isEqual(today) || input.isAfter(today)) {
                    // ensure input is in 30 minutes time bucket
                    if (input.getMinute() % 30 == 0) {
                        // ensure input is from 7am to 830pm
                        if (input.getHour() >= 8 && input.getHour() <= 20)
                            return input;
                        else {
                            System.out.println("Time entered must be from 07:00 to 20:30");
                        }
                    } else {
                        System.out.println("Date time entered should be in 30 minutes time buckets.");
                    }
                }
                    
                else
                    System.out.println("The datetime you have entered should be for the future, no earlier than the current datetime! Try again.");
            } catch (Exception exception) {
                System.out.println("Invalid date format entered, ensure correct format is adhered to " +
                    "and input is entered as a single line.");
                System.out.println("Enter date (DD-MM-YYYY HH:mm): ");
            }
        }
    }

    public static LocalDateTime stringToDateTime(String stringInput) {
        return LocalDateTime.parse(stringInput, formatter);
    }

    // formats a local date time object following our format to a string
    public static String dateTimeToString(LocalDateTime datetime) {
        if (datetime == null)
            return "- ";
        return datetime.format(formatter);
    }
    
    /**
	 * prompts the user for either a 'y' or 'n' and rejects everything else
	 * 
     *@return char returns either a 'y' or 'n' depending on the input
	 */
    
    // helper method to get a yes or no reply
    public static char getYesOrNo() {
        char reply = scanner.nextLine().charAt(0);
        while (reply != 'y' && reply != 'n') {
            System.out.println("Only 'y' or 'n' are allowed.");
            reply = scanner.nextLine().charAt(0);
        }
        return reply;
    }

    public static String nextLine() {
        
        return scanner.nextLine();
    }

    // convert the string time-time to 30 min time slices, eg: "1030 - 1130" => {"10:30", "11:00"};
    // # note: formatting of " - "
    // note: 11:30 is not added since that timing and onwards is free
    public static Set<String> getTimeSlices(String timing) {
        Set<String> timingInSlices = new HashSet<>();
        String[] startEnd  = timing.split(" - ");
        String start = startEnd[0].trim(), end = startEnd[1].trim();
        while (!start.equals(end)) {
            timingInSlices.add(start);
            String[] hrMin = start.split(":");
            int hr = Integer.parseInt(hrMin[0]), min = Integer.parseInt(hrMin[1]);
            int carry = 0;
            min += 30;
            carry = min / 60;
            min = min % 60;
            hr = carry + hr; // do not need to take care of edge cases like 23:30 to 24:00, since we will never reach that time
            start = hr + ":" + min;
            if (hr < 10) {
                start = "0" + start;
            }
            if (start.length() == 4) {
                start = start + "0";
            }
        }
        return timingInSlices;
    }

    // convert string time-time to index in array of 30min slices
    // returns an int array of start to end index to check, NOTE: the end index is not inclusive
    // eg: "00:00 - 01:30" => [0, 2]     # note: formatting of " - "
    public static int[] getTimeSliceIndexes(String timing) {
        String[] startEnd = timing.split(" - ");
        int[] result = new int[2];
        int i = 0;
        for (String time: startEnd) {
            String[] hrMin = time.split(":");
            int hr = Integer.parseInt(hrMin[0]);
            int min = Integer.parseInt(hrMin[1]);
            int idx = hr * 2 + min % 30;
            result[i++] = idx;
        }
        return result;
    }

    public static String promptMonToFri() {
        System.out.println("Select a choice from mon to fri: (1-5) ");
        System.out.println("1. Monday");
        System.out.println("2. Tuesday");
        System.out.println("3. Wednesday");
        System.out.println("4. Thursday");
        System.out.println("5. Friday");
        int choice = nextInt(1, 5);
        switch (choice) {
            case 1:
                return "mon";
            case 2:
                return "tue";
            case 3:
                return "wed";
            case 4:
                return "thur";
            case 5:
                return "fri";
            default:
                return null;
        }
    }

    // returns a time stamp in 24 hours format, in 30 minute time slices
    // eg: 10:00 or 18:30
    
    /**
	 * Prompts for an input in 24 hour format, between a range in 30 min intervals. Rejects anything that does not fit
	 * 
     *@return String returns a string in that specified format
	 */
    
    public static String prompt24HrTime() {
        boolean pass = false;
        String hrMinString = null;
        while (!pass) {
            System.out.println("Enter a time in 24 hour format, must be in intervals of 30 minutes (00:00 - 23:30): ");
            hrMinString = nextLine();
            String[] hrMin = hrMinString.split(":");
            if (hrMin.length != 2) {
                System.out.println("Enter the time format with ':', eg: '10:00' ");
            } else {
                try {
                    int hr = Integer.parseInt(hrMin[0]);
                    int min = Integer.parseInt(hrMin[1]);
                    if (hr < 24 && hr >= 0 && (min == 0 || min == 30))
                        pass = true;
                    else {
                        System.out.println("Invalid data. Check hour is between 00 to 23, minute is either 00 or 30");
                    }
                } catch (Exception e) {
                    System.out.println("Invalid format entered. Only use numeric literals to represent the hour and minutes.");
                }
            }
        }
        return hrMinString;
    }

    public static String nextSecret() {
        Console console = System.console();
        return String.valueOf(console.readPassword());
    }
    
    /**
	 * Takes in a string input and hashes it into integers based on its ASCII number
	 * 
     *@param inPW the Password in plaintext to hash
     *
     *@return String the Hashed Password
	 */

    public static String passwordHash(String inPW) {
    	String outPW = new String();
    	for (int i = 0; i < inPW.length(); ++i) {
    	    char ch = inPW.charAt(i);
            int n = (int)ch - (int)'a' + 1;
            if (n == 10 || n == 13)
                n += 1;
            n = Math.max(n, 1);
    	    outPW += String.valueOf(n);
    	}
    	return outPW + "1";
    }
}
