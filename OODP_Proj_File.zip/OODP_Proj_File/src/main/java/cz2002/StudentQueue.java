package cz2002;

public interface StudentQueue {

    // remove by UID
    public Student removeStudentByID(String id);

    // remove head of queue
    public Student removeHead();

    // add to the queue
    public void addHead(Student student);

    public int getSize();

    public String toString();
}
