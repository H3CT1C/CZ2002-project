package cz2002;

import java.rmi.activation.ActivationSystem;
import java.util.HashMap;
import java.util.Map;

public class Schedule {
    private String courseID;

    enum Activity { TUT, LAB, LECT }
    private Map<String, Map<String, Integer>> guidelines;

    /*
        {
            "tut": {
                "numSessions": 8
                "duration": 1
                "freq": 1
            },
            "lab": {

            },
            "lect": {

            }
        }

    */

    public Schedule(String courseID, Map<String, Map<String, Integer>> guidelines) {
        this.courseID = courseID;
        this.guidelines = guidelines;
    }

    public Schedule(String courseID) {
        this.courseID = courseID;
        guidelines = new HashMap<>();
        for (Activity act: Activity.values()) {
            Map<String, Integer> activityMap = new HashMap<>();
            String activity = null;
            switch (act) {
                case TUT:
                    activity = "TUT";
                    break;
                case LAB:
                    activity = "LAB";
                    break;
                case LECT:
                    activity = "LECT";
                    break;
            }
            activity = activity.toLowerCase();
            System.out.printf("Enter the number of sessions for %s: \n", activity);
            int numSessions = IO.nextInt(1, 13);
            System.out.printf("Enter the duration for %s in hours (1 or 2): \n", activity);
            int duration = IO.nextInt(1, 2);
            System.out.printf("Enter the weekly frequency of %s (1 or 2): \n", activity);
            int freq = IO.nextInt(1, 2);
            activityMap.put("numSessions", numSessions);
            activityMap.put("duration", duration);
            activityMap.put("freq", freq);
            guidelines.put(activity, activityMap);
        }
    }

    public int getNumTutorials() {
        return guidelines.get("tut").get("numSessions");
    }

    public int getDurationOfTut() {
        return guidelines.get("tut").get("duration");
    }

    public int getFrequencyOfTut() {
        return guidelines.get("tut").get("freq");
    }


    public int getNumLabs() {
        return guidelines.get("lab").get("numSessions");
    }

    public int getDurationOfLab() {
        return guidelines.get("lab").get("duration");
    }

    public int getFrequencyOfLabs() {
        return guidelines.get("lab").get("freq");
    }

    public int getNumLects() {
        return guidelines.get("lect").get("numSessions");
    }

    public int getDurationOfLects() {
        return guidelines.get("lect").get("duration");
    }

    public int getFrequencyOfLects() {
        return guidelines.get("lect").get("freq");
    }
    

    /**
     * Class constructor's contract   
     * 
     * @param groupID id of the group for which index to build
     * 
     * @return mapped timetable
     * 
     */
    public Map<String, Map<String, String>> buildTimetable(String groupID) {
        Map<String, Map<String, String>> mappedTimetable = new HashMap<>();
        
        for (Activity act: Activity.values()) {
            String activity = null;
            switch (act) {
                case TUT:
                    activity = "TUT";
                    break;
                case LAB:
                    activity = "LAB";
                    break;
                case LECT:
                    activity = "LECT";
                    break;
            }
            activity = activity.toLowerCase();
            System.out.printf("Enter the week for the first %s: \n", activity);
            int firstWeek = IO.nextInt(1, 13);
            StringBuilder sb = new StringBuilder();
            int numSessions = guidelines.get(activity).get("numSessions");
            for (int i=0; i<numSessions; i++) {
                sb.append(firstWeek+i);
                if (i != numSessions - 1)
                    sb.append(", ");
            }
            Map<String, String> actDetails = new HashMap<>();
            actDetails.put("weeks", sb.toString());
            System.out.printf("Enter the day of the %s: \n", activity);
            String tutDay = IO.promptMonToFri();
            actDetails.put("day", tutDay);
            System.out.println("Enter the start time for " + activity + ": ");
            String startTime = IO.prompt24HrTime().trim();
            int hours = guidelines.get(activity).get("duration");
            hours += Integer.parseInt(startTime.substring(0, 2));
            String endTime = String.valueOf(hours) + ":" + startTime.substring(3, 5);
            String actTiming = startTime + " - " + endTime;
            actDetails.put("time", actTiming);
            String reason = courseID + " " + groupID + activity;
            String tutVenue = VenueBookingManager.bookVenue("week"+firstWeek, tutDay, actTiming, reason, numSessions, 1);
            System.out.println("Successfully booked " + tutVenue);
            actDetails.put("venue", tutVenue);
            mappedTimetable.put(activity, actDetails);
        }
        return mappedTimetable;
    }


    /*
        {
            "tut": {
                "numSessions": 8
                "duration": 1
                "freq": 1
            },
            "lab": {

            },
            "lect": {

            }
        }

    */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(" -- - %s Course Schedule ---\n", this.courseID));

        for (Activity act: Activity.values()) {
            String activity = null;
            switch (act) {
                case TUT:
                    activity = "TUT";
                    break;
                case LAB:
                    activity = "LAB";
                    break;
                case LECT:
                    activity = "LECT";
                    break;
            }
            activity = activity.toLowerCase();
            sb.append(" - - " + activity + " - - \n");
            for (Map.Entry<String, Integer> entry: guidelines.get(activity).entrySet()) {
                sb.append(String.format("%s: %d \n", entry.getKey(), entry.getValue()));
            }
        }
        return sb.toString();
    }
}
