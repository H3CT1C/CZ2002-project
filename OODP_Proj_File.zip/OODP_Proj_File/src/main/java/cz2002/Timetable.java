package cz2002;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Timetable {
    private String groupID;
    private String courseID;
    private Map<String, Map<String, String>> mappedTimetable;
    /*
        {
            "tut": {
                "weeks": "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13",
                "day": "Monday"
                "time": "11:30 - 12:30",
                "venue": "TR+18"
            }, 
            "lab": {
                "weeks": "1, 3, 5, 7, 9, 11, 13",
                "day": "Tuesday",
                "time": "12:30 - 14:30",
                "venue": "HWLAB3"
            },
            "lect" : {
                ...
            }
        }
    */

    
    // assumes correct and valid data has been passed in
    public Timetable(String groupID, String courseID, Map<String, Map<String, String>> mappedTimetable)
    {
        this.groupID = groupID;
        this.courseID = courseID;
        this.mappedTimetable = mappedTimetable;
        
    }

    public Map<String, Map<String, String>> getDetails() {
        return mappedTimetable;
    }


    /**
     * method to compare 2 timetables for clashes
     * @param t1, a timetable object to check with another timetable
     * @param t2, a timetable object to check with another timetable
     * 
     * @return boolean whether there are clashes
    */
    public boolean checkClashes(Timetable t1, Timetable t2) {
        // first store timetable t1's details into a map for O(1) lookup
        // week-day: {timings}
        // example entry: "1-Monday": {"11:30", "12:00", "12:30"}
        Map<String, Set<String>> weeksTiming = new HashMap<>();
        Iterator it = t1.getDetails().entrySet().iterator();
        while (it.hasNext()) { // iterating through labs and tut of t1
            Map.Entry<String, Map<String, String>> pair = (Map.Entry) it.next();
            Map<String, String> details = pair.getValue();
            String[] weeksStr = details.get("weeks").split(", ");
            String day = details.get("day");
            String timing = details.get("time");
            Set<String> timingInSlices = IO.getTimeSlices(timing);
            for (String week: weeksStr) {
                String weekAndDay = week.trim() + "-" + day.trim();
                Set<String> timings = weeksTiming.getOrDefault(weekAndDay, new HashSet<String>());
                timings.addAll(timingInSlices);
                weeksTiming.put(weekAndDay, timings);
            }
        }

        // now iterate through t2, looking for clashes
        it = t2.getDetails().entrySet().iterator();
        while (it.hasNext()) { // iterating through labs and tut of t2
            
            Map.Entry<String, Map<String, String>> pair = (Map.Entry) it.next();
            Map<String, String> details = pair.getValue();
            String[] weeksStr = details.get("weeks").split(", ");
            String day = details.get("day");
            String timing = details.get("time");
            Set<String> timingInSlices = IO.getTimeSlices(timing);
            for (String week: weeksStr) {
                String weekAndDay = week.trim() + "-" + day.trim();
                Set<String> timings = weeksTiming.getOrDefault(weekAndDay, new HashSet<String>());
                if (timings.size() == 0)
                    continue;
                if (!Collections.disjoint(timings, timingInSlices))
                    return true;
            }
        }
        return false;
    }

    /*
        {
            "tut": {
                "weeks": "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13",
                "day": "Monday"
                "time": "11:30 - 12:30",
                "venue": "TR+18"
            }, 
            "labs": {
                "weeks": "1, 3, 5, 7, 9, 11, 13",
                "day": "Tuesday",
                "time": "12:30 - 14:30",
                "venue": "HWLAB3"
            },
            "lect" : {
                ...
            }
        }
    */
    public String toSaveString() {
        StringBuilder sb = new StringBuilder();
        String[] acts = new String[] {"tut", "lab", "lect"};
        for (int i=0; i<acts.length; i++) {
            sb.append("--" + acts[i] + "\n");
            Map<String, String> map = mappedTimetable.get(acts[i]);
            for (Map.Entry<String,String> entry: map.entrySet()) {
                sb.append(String.format("%s: %s \n", entry.getKey(), entry.getValue()));
            }
        }
        return sb.toString();
    }


    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(" -- - Displaying %s %s timetable -- - \n", courseID, groupID));
        String[] acts = new String[] {"tut", "lab", "lect"};
        for (String act: acts) {
            sb.append(String.format(" - - %s - - \n", act));
            for (Map.Entry<String, String> entry: mappedTimetable.get(act).entrySet()) {
                sb.append(String.format(" %s: %s \n", entry.getKey(), entry.getValue()));
            }
        }
        sb.append("\n");
        return sb.toString();
    }

}
