package cz2002;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;


/**
 * Main application boundary class for UI
 * 
 */
public class StarsApp {

    private static final String schoolsDataFilePath = "SchoolData.txt";
    private static final String courseDataFilePath = "CourseData.txt";
    private static final String groupDataFilePath = "GroupData.txt";
    private static final String studentsDataFilePath = "StudentData.txt";
    private static final String adminsDataFilePath = "AdminData.txt";
    private static final String venueDataFilePath = "VenueData.txt";


    private static List<Student> students = new ArrayList<>();
    private static List<School> schools = new ArrayList<>();
    private static List<Admin> admins = new ArrayList<>();
    private static List<Venue> venues = new ArrayList<>();

    /**
     * Main method for entry point
     * 
     * @throws IOException if failing to load data from db
     */
    public static void main(String[] args) throws IOException {
        
        try {
            venues = Init.initializeVenue();
            students = Init.initializeStudents();
            schools = Init.initializeSchools(students, venues);
            admins = Init.initializeAdmins();
            
        } catch (IOException e) {
            System.out.println("Error loading initial data from db.");
            System.out.println(e);
        }

        boolean exit = false;
        while (!exit) {
            User authenticatedUser = null;
            int choice = -1;
            while (authenticatedUser == null) {
                System.out.println();
                System.out.println("Select portal to login to STARS:");
                System.out.println("1. Student Portal");
                System.out.println("2. Admin Portal");
                System.out.println("3. Exit STARS program");
                choice = IO.nextInt(1, 3);
                if (choice == 1)
                    authenticatedUser = Authenticate.loginStudentPortal(students);
                else if (choice == 2)
                    authenticatedUser = Authenticate.loginAdminPortal(admins);
                else {
                    exit = true;
                    break;
                }
                    
                if (authenticatedUser == null) {
                    System.out.println("Username and password not recognized! Try again.");
                }
            }
                
            if (choice == 1) {
                runStudentProgram( (Student) authenticatedUser);
            } 
            else if (choice == 2) {
                runAdminProgram( (Admin) authenticatedUser);
            } else {
                System.out.println("Exiting STARS...");
            }
        }
        System.out.println("END, enter any digit to quit.");
        IO.nextInt();
    }

    /**
     * Runs the student terminal
     * 
     * @param student authenticated student object for the current session
     * 
     * @throws IOException if failed to save modified student object into the student data file
     */
    public static void runStudentProgram(Student student) throws IOException {
        boolean running = true;
        while (running) {
            int choice = -1;
            System.out.println();
            System.out.println("----- Student Panel -----");
            System.out.println("1. Check groups enrolled in");
            System.out.println("2. Check groups waitlisted in");
            System.out.println("3. Enroll in a course's group");
            System.out.println("4. Check vacancy for a course's group");
            System.out.println("5. Drop a course");
            System.out.println("6. Print your timetable.");
            System.out.println("7. Swap Indexes wth another student");
            System.out.println("8. View timetable for a specific index");
            System.out.println("9. Change password");
            System.out.println("10. Logout");
            System.out.println("Enter choice (1-10): ");
            choice = IO.nextInt(1, 10);
            switch (choice) {
                case 1: {
                    checkGroupsEnrolled(student);
                    break;
                }
                case 2: {
                    checkGroupsWaitListed(student);
                    break;
                }
                case 3: {
                    enrollInAGroup(student);
                    break;
                }
                case 4: {
                    checkGroupVacancy();
                    break;
                }
                case 5: {
                    dropCourse(student);
                    break;
                }
                case 6: {
                    printMyTimetable(student);
                    break;
                }
                case 7: {
                    swapIndexes(student);
                    break;
                }
                case 8: {
                    checkTimeTableOfIndex();
                    break;
                }
                case 9: {
                    changeMyPassword(student);
                    break;
                }
                case 10: {
                    running = false;
                    break;
                }
                default: {
                    System.out.println("Choice not recognized. Try again.");
                }
            }
        }
    }

    /**
     * changes a student password
     * 
     * @param student takes in a student object to change password
     * @throws IOException
     * 
     */
    private static void changeMyPassword(Student student) throws IOException {
        System.out.println("Enter your old password: ");
        String oldPassword = IO.passwordHash(IO.nextSecret());
        if (student.getPassword().equals(oldPassword)) {
            System.out.println("Enter your new password: ");
            String newPassword = IO.passwordHash(IO.nextSecret());
            System.out.println("Enter your new password again: ");
            String newPassword2 = IO.passwordHash(IO.nextSecret());
            while (!newPassword.equals(newPassword2)) {
                System.out.println("Password entered does not match! Try again!");
                System.out.println("Enter your new password: ");
                newPassword = IO.passwordHash(IO.nextSecret());
                System.out.println("Enter your new password again: ");
                newPassword2 = IO.passwordHash(IO.nextSecret());
            }
            student.setPassword(newPassword);
            System.out.println("Successfully changed password!");
            // writes to the group data file
            StringBuilder sb = new StringBuilder();
            try(BufferedReader br = new BufferedReader(new FileReader(studentsDataFilePath))) {
                String line = br.readLine();
                while (line != null) {
                    if (line.split(": ").length < 2) {
                        sb.append(line + "\n");
                        continue;
                    }
                    if (line.split(": ")[1].equalsIgnoreCase(student.getUID())) {
                        sb.append(line + "\n");
                        for (int i=0; i<3; i++)
                            sb.append(br.readLine() + "\n");
                        sb.append("Password: " + newPassword + "\n");
                        br.readLine();
                    } else {
                        sb.append(line + "\n");
                    }
                    line = br.readLine();
                }
            }
            try {
                FileWriter f2 = new FileWriter(studentsDataFilePath, false);
                f2.write(sb.toString());
                f2.close();
            
            } catch (IOException e) {
                e.printStackTrace();
            } 
        } else {
            System.out.println("Password entered was invalid!");
        }
    }

    /**
     * checks the timetable for a particular index
     * 
     */
    private static void checkTimeTableOfIndex() {
        System.out.println("Select school name of the index: ");
        String schoolName = IO.nextLine();
        System.out.println("Enter course id: ");
        String courseID = IO.nextLine();
        System.out.println("Enter the group id: ");
        String groupID = IO.nextLine();
        School school = getSchool(schoolName);
        if (school == null) {
            System.out.println("School does not exist!");
            return ;
        }
        Course course = school.findACourse(courseID);
        if (course == null) {
            System.out.println("Course does not exist in the school.");
            return;
        }
        Group group = course.findGroup(groupID);
        if (group == null) {
            System.out.println("Group does not exist.");
            return;
        }
        System.out.println(group.getTimetable().toString());
    }


    /**
     * Coordinates the logic to swap indexes between 2 students
     * 
     * @param student authenticated student object of the session
     * 
     */
    private static void swapIndexes(Student student) {
        System.out.println("Select the School of the course: ");
        for (int i=0; i<schools.size(); i++) {
            System.out.println(String.format("%d. %s", i+1, schools.get(i).getSchoolName()));
        }
        int idx = IO.nextInt(1, schools.size()) - 1;
        School sch = schools.get(idx);
        List<Course> courses = sch.getAllCourses();
        System.out.println("Select the course: ");
        for (int i=0; i<courses.size(); i++) {
            System.out.println(String.format("%d. %s", i+1, courses.get(i).getCourseID()));
        }
        idx = IO.nextInt(1, courses.size()) - 1;
        Course course = courses.get(idx);
        List<Group> groups = course.getGroups();
        boolean enrolled = false;
        Group group1 = null; // group this student is in
        for (int i=0; i<groups.size() && !enrolled; i++) {
            Group g = groups.get(i);
            List<Student> studs = g.getStudentsEnrolled();
            if (studs.isEmpty())
                continue;
            for (Student s: studs) {
                if (s.getUID().trim().equalsIgnoreCase(student.getUID().trim())) {
                    enrolled = true;
                    group1 = g;
                    break;
                }
            }
        }
        if (!enrolled) {
            System.out.println("You are not enrolled in any index of this course. Cannot do swapping.");
            return;
        }
        System.out.println("Below shows the group IDs in this course");
        for (Group g: groups) {
            System.out.println(g.getGroupID());
        }
        System.out.println("Enter the other student's course group ID: ");
        String group2Idx = IO.nextLine().trim();
        Group group2 = course.findGroup(group2Idx); /////
        if (group2 == null) {
            System.out.println("Invalid group index. Not found in this course.");
            return;
        }
            
        
        System.out.println("Login using the other students credentials: ");
        Student student2 = null;
        while (student2 == null) {
            // prompt the login for student 2
            student2 = (Student) Authenticate.loginStudentPortal(students);
        }
        if (group2Idx.equalsIgnoreCase(group1.getGroupID())) {
            System.out.println("You entered an index to swap which you are already enrolled in.");
            return;
        }
        // check student 2 has enrolled in the group specified
        boolean student2Valid = false;
        List<Group> student2Groups = student2.getGroups();
        for (int i=0; i<student2Groups.size(); i++) {
            Group grp2 = student2Groups.get(i);
            if (grp2.getCourseID().equalsIgnoreCase(course.getCourseID()) && grp2.getGroupID().equalsIgnoreCase(group2Idx)) {
                student2Valid = true;
                break;
            }
        }
        // can do swapping
        if (student2Valid) {
            // update grp changes
            EnrolledList students1 = group1.getEnrolledList();
            students1.removeStudentByID(student.getUID());
            students1.addStudent(student2);
            group1.setEnrolledList(students1);

            EnrolledList students2 = group2.getEnrolledList();
            students2.removeStudentByID(student2.getUID());
            students2.addStudent(student);
            group2.setEnrolledList(students2);

            // update student changes
            List<Group> groups1 = student.getGroups();
            groups1.remove(group1);
            groups1.add(group2);
            student.setGroups(groups1);

            List<Group> groups2 = student2.getGroups();
            groups2.remove(group2);
            groups2.add(group1);
            student2.setGroups(groups2);

            System.out.println("Successfully swapped indexes.");

        } else {
            System.out.println("Student is not enrolled in this index. Cannot perform swap.");
        }

        saveStateOfGroup();

    }

    /**
     * Prints a student timetable
     * 
     * @param student authenticated student of the current session
     * 
     */
    private static void printMyTimetable(Student student) {
        System.out.println("Displaying timetable for courses you are enrolled in: \n");
        System.out.println("----------------------------------------------------");
        for (Group g: student.getGroups()) {
            System.out.println(g.getTimetable().toString());
        }
    }

    /**
     * Coordinates the logic to drop a student from a course
     * 
     * @param student authenticated student object for the session
     * 
     */
    private static void dropCourse(Student student) {
        System.out.println("Are you dropping a course you are currently enrolled in? If not, then it will be from waitlist. (y/n)");
        char choice = IO.getYesOrNo();
        List<Group> groupsSelected = choice == 'y' ? student.getGroups(): student.getWaitlists();
        if (groupsSelected.size() == 0) {
            System.out.println("Nothing to drop in the list.");
            return;
        }
        System.out.println("Select the choice from below: ");
        int i = 1;
        for (Group g: groupsSelected) {
            System.out.println(i++ + ": " + g.getCourseID() + " " + g.getGroupID());
        }
        
        int input = IO.nextInt(1, groupsSelected.size());
        Group g = groupsSelected.get(input-1);
        List<Group> updatedEnrolled = student.getGroups();
        if (updatedEnrolled.contains(g))
            updatedEnrolled.remove(g);
        student.setGroups(updatedEnrolled);
        List<Group> updatedWaitList = student.getWaitlists();
        if (updatedWaitList.contains(g)) 
            updatedWaitList.remove(g);
        student.setWaitLists(updatedWaitList);
        g.unenrollStudent(student.getUID(), choice);
        saveStateOfGroup();
    }

    /**
     * Checks the vacancy of a group
     * 
     */
    private static void checkGroupVacancy() {
        System.out.println("Select the school of the course: ");
        for (int i=0; i<schools.size(); i++) {
            System.out.println(i+1 + ": " + schools.get(i).getSchoolName());
        }
        int choice = IO.nextInt(1, schools.size());
        School s = schools.get(choice-1);
        System.out.println("Select the course ID: ");
        for (int i=0; i<s.getAllCourses().size(); i++) {
            System.out.println(i+1 + ": " + s.getAllCourses().get(i).getCourseID());
        }
        choice = IO.nextInt(1, s.getAllCourses().size());
        Course c = s.getAllCourses().get(choice - 1);
        System.out.println("Select the group ID: ");
        for (int i=0; i<c.getGroups().size(); i++) {
            System.out.println(i+1 + ": " + c.getGroups().get(i).getGroupID());
        }
        choice = IO.nextInt(1, c.getGroups().size());
        Group g = c.getGroups().get(choice - 1);
        System.out.println(String.format("%s %s vacancy: %d / %d", g.getCourseID(), g.getGroupID(), g.getVacancies(), g.getSlots()));
        
    }

    /**
     * Enrolls a student into a group
     * 
     * @param student authenticated student for the session
     * 
     */
    private static void enrollInAGroup(Student student) {
        System.out.println("Enter the school the course is located in: ");
        String schoolName = IO.nextLine();
        for (School s: schools) {
            if (s.getSchoolName().equalsIgnoreCase(schoolName)) {
                System.out.println("Enter the ID for the course you wish to enroll in: ");
                String courseID = IO.nextLine();
                for (Course c: s.getAllCourses()) {
                    if (c.getCourseID().equalsIgnoreCase(courseID)) {
                        System.out.println("Here is an overview of the possible groups: ");
                        int idx = 1;
                        for (String id: c.getAllGroupsID())
                            System.out.println(idx++ + ". " + id);
                        System.out.println("Enter the choice of group you wish to enroll in (1-" + (idx-1) + "): ");
                        idx = IO.nextInt(1, idx-1);
                        Group g = c.findGroup(c.getAllGroupsID().get(idx-1));
                        List<Group> groupsCurrentlyEnrolled = student.getGroups();
                        Timetable t1 = g.getTimetable();
                        for (Group currentG: groupsCurrentlyEnrolled) {
                            if (t1.checkClashes(t1, currentG.getTimetable())) {
                                System.out.println("Clashes with existing time table found! Check group: " + currentG.getCourseID() + " " + currentG.getGroupID());
                                return;
                            }
                        }
                        // check for AU restriction before attempting to enroll
                        if (student.getAU() + c.getAU() > 23) {
                            System.out.println("You cannot enroll in this course due to AU restrictions. AU is capped at 23. This includes courses you are placed in wait lists.");
                        } 
                        
                        else {
                            if (student.canEnroll(g)) {
                                g.enrollStudent(student, c.getAU()); // need to save in the file, this also handles for waitlist
                                // save the current state of group data here
                                saveStateOfGroup();
                            }
                        }
                        return;
                    }
                }
                System.out.println("Course does not exist in " + schoolName);
            }
        }
        System.out.println("School entered does not exist.");
    }

    /**
     * helper method to save current state into group data file
     * 
     */
    private static void saveStateOfGroup() {
        StringBuilder sb = new StringBuilder();
        for (School s: schools) {
            sb.append("||" + s.getSchoolName() + "\n");
            for (Course c: s.getAllCourses()) {
                sb.append("|" + c.getCourseID() + "\n");
                for (Group g: c.getGroups()) {
                    sb.append(g.toSaveString());
                }
            }
        }
        try {
            FileWriter f2 = new FileWriter(groupDataFilePath, false);
            f2.write(sb.toString());
            f2.close();
        
        } catch (IOException e) {
            e.printStackTrace();
        }  
        return;
    }

    /**
     * coordinates the logic to check a group's wait list
     * 
     * @param student authenticated student for the session
     * 
     */
    private static void checkGroupsWaitListed(Student student) {
        System.out.println("The groups you are placed in waitlist are as follows: ");
        for (Group g: student.getWaitlists()) {
            System.out.println("------------------------------");
            System.out.println("CourseID : " + g.getCourseID());
            System.out.println("GroupID: " + g.getGroupID());
        }
    }

    /**
     * coordinates the logic to check a group's enrolled list
     * 
     * @param student authenticated student for the session
     * 
     */
    private static void checkGroupsEnrolled(Student student) {
        System.out.println("The groups you are enrolled in are as follows: ");
        for (Group g: student.getGroups()) {
            System.out.println("------------------------------");
            System.out.println("CourseID : " + g.getCourseID());
            System.out.println("GroupID: " + g.getGroupID());
        }
    }

    /**
     * Runs the admin program for an admin
     * 
     * @param admin authenticated admin object for the session
     * 
     * @throws IOException
     * 
     */
    private static void runAdminProgram(Admin admin) throws IOException {
        boolean running = true;
        while (running) {
            int choice = -1;
            System.out.println();
            System.out.println("----- Admin Panel -----");
            System.out.println("1. Add a new student");
            System.out.println("2. Add a new course");
            System.out.println("3. View all schools");
            System.out.println("4. View a particular school's info");
            System.out.println("5. View a particular course info");
            System.out.println("6. View a particular index's info");
            System.out.println("7. Edit Student's STARS Access Periods");
            System.out.println("8. Print Student list by course");
            System.out.println("9. Print student list by course and index");
            System.out.println("10. Logout");
            System.out.println("Enter choice (1-10): ");
            choice = IO.nextInt(1, 10);
            switch (choice) {
                case 1: {
                    addAndSaveStudent(admin);
                    break;
                }
                case 2: {
                    addAndSaveCourse(admin.getAccessLevel());
                    break;
                }
                case 3: {
                    viewAllSchools(admin.getAccessLevel());
                    break;
                }
                case 4: {
                    viewAParticularSchool(admin.getAccessLevel());
                    break;
                }
                case 5: {
                    viewAParticularCourse(admin.getAccessLevel());
                    break;
                }
                case 6: {
                    viewAParticularGroup(admin.getAccessLevel());
                    break;
                }
                case 7: {
                    System.out.println("Set access period for a specific student? If no, then set by year. (y/n)");
                    char ans = IO.getYesOrNo();
                    if (ans == 'y') {
                        System.out.println("Enter the Student's ID: ");
                        String studentID = IO.nextLine();
                        setAccessPeriodForSpecificUser(admin.getAccessLevel(), studentID);
                    } else {
                        System.out.println("Enter the year for students in your school, for which you wish to edit their access period: ");
                        int year = IO.nextInt(1, 4);
                        setAccessPeriodForMultipleUsers(admin.getAccessLevel(), year);
                    }
                    break;
                }
                case 8: {
                    System.out.println("Enter school name that the course belongs to: ");
                    String schoolName = IO.nextLine();
                    System.out.println("Enter course name: ");
                    String courseID = IO.nextLine();
                    System.out.println(viewStudentListByCourse(admin.getAccessLevel(), schoolName, courseID));
                    break;
                }
                case 9: {
                    System.out.println("Enter school name that the course belongs to: ");
                    String schoolName = IO.nextLine();
                    System.out.println("Enter course name: ");
                    String courseID = IO.nextLine();
                    System.out.println("Enter group ID: ");
                    String groupID = IO.nextLine();
                    System.out.println(viewStudentListByCourseIndex(admin.getAccessLevel(), schoolName, courseID, groupID));
                    break;
                }
                case 10:
                    running = false;
                    break;
                default: {
                    System.out.println("Choice not recognized. Try again.");
                }
            }
        }
    }

    /**
     * Views a student list by the course
     * 
     * @param accessLevel access level of the user 
     * @param schoolName school name of the course
     * @param courseID course id to search
     * 
     * @return the string response to be displayed
     */
    private static String viewStudentListByCourse(AccessLevel accessLevel, String schoolName, String courseID) {
        StringBuilder sb = new StringBuilder();
        if (accessLevel.hasAccess(schoolName, "read")) {
            School school = getSchool(schoolName);
            if (school == null) {
                sb.append("School does not exist!");
                return sb.toString();
            }
            Course course = school.findACourse(courseID);
            if (course == null) {
                sb.append("Course does not exist in the school.");
                return sb.toString();
            }
            List<Group> groups = course.getGroups();
            if (groups == null) {
                sb.append("Group specified does not exist in the course.");
                return sb.toString();
            }
            for (Group g: groups) {
                sb.append(g.displayStudentsEnrolled());
            }
            return sb.toString();
        } else {
            return "No access to read this school! \n";
        }
    }

    /**
     * gets a school object from the list of schools
     * 
     * @param schoolName school name to search for 
     * 
     * @return the school object, null if does not exist
     * 
     */
    private static School getSchool(String schoolName) {
        for (School s: schools) {
            if (s.getSchoolName().trim().equalsIgnoreCase(schoolName.trim())) {
                return s;
            }
        }
        return null;
    }

    /**
     * Views a student list by specific course and index
     * 
     * @param accessLevel access level of the student
     * @param schoolName school name of the group
     * @param courseID course id of the group
     * @param groupID group id of the group
     * 
     * @return a string response to display
     * 
     */
    private static String viewStudentListByCourseIndex(AccessLevel accessLevel, String schoolName, String courseID, String groupID) {
        StringBuilder sb = new StringBuilder();
        if (accessLevel.hasAccess(schoolName, "read")) {
            School school = getSchool(schoolName);
            if (school == null) {
                sb.append("School does not exist! \n");
                return sb.toString();
            }
            Course course = school.findACourse(courseID);
            if (course == null) {
                sb.append("Course does not exist in the school. \n");
                return sb.toString();
            }
            Group group = course.findGroup(groupID);
            if (group == null) {
                sb.append("Group specified does not exist in the course. \n");
                return sb.toString();
            }
            sb.append(group.displayStudentsEnrolled());
            return sb.toString();
        } else {
            return "No access to read this school! \n";
        }
    }

    /**
     * Set access period for multiple users by the academic year
     * 
     * @param accessLevel access level of the admin
     * @param year academic year of students to change
     * 
     */
    private static void setAccessPeriodForMultipleUsers(AccessLevel accessLevel, int year) {
        LocalDateTime start = null, end = null;
        while (start == null || end == null || !start.isBefore(end)) {
            System.out.println("Enter the new start access time: ");
            start = IO.promptUserLocalDateTime();
            System.out.println("Enter the new end access time: ");
            end = IO.promptUserLocalDateTime();
            if (!start.isBefore(end)) {
                System.out.println("Start access time cannot be after the end access time. Please try again!");
            }
        }
        StringBuilder sb = new StringBuilder();
        Iterator<Student> it = students.iterator();
        System.out.println("Below shows the students affected by this change: ");
        while (it.hasNext()) {
            Student s = it.next();
            if (accessLevel.hasAccess(s.getSchool(), "write") && year == s.getAcademicYear()) {
                s.setAddDropTime(start, end);
                System.out.println(s.toString());
            }    
            sb.append(s.toSaveString());
        }
        try {
            FileWriter f2 = new FileWriter(studentsDataFilePath, false);
            f2.write(sb.toString());
            f2.close();
        
        } catch (IOException e) {
            e.printStackTrace();
        }   
    }

    /**
     * Set access period for a specific user
     * 
     * @param accessLevel access level of the admin
     * @param studentID student id for the student to be changed
     * 
     */
    private static void setAccessPeriodForSpecificUser(AccessLevel accessLevel, String studentID) {
        // first find the student to modify
        Student student = null;
        Iterator<Student> it = students.iterator();
        while (it.hasNext()) {
            Student s = it.next();
            if (s.getUID().equalsIgnoreCase(studentID)) {
                if (accessLevel.hasAccess(s.getSchool(), "write")) {
                    student = s;
                    students.remove(s);
                } else {
                    System.out.println("You do not have the rights to edit access period for " + s.getSchool());
                }
                break;
            }
        }
        if (student == null) {
            System.out.println("The ID entered does not match any student's ID!");
            return;
        }
        LocalDateTime start = null, end = null;
        while (start == null || end == null || !start.isBefore(end)) {
            System.out.println("Enter the new start access time: ");
            start = IO.promptUserLocalDateTime();
            System.out.println("Enter the new end access time: ");
            end = IO.promptUserLocalDateTime();
            if (!start.isBefore(end)) {
                System.out.println("Start access time cannot be after the end access time. Please try again!");
            }
        }
        student.setAddDropTime(start, end);
        students.add(student);
        StringBuilder sb = new StringBuilder();
        for (Student s: students) {
            sb.append(s.toSaveString());
        }
        System.out.println("Kindly verify the changes below: ");
        System.out.println(student.toString());
        try {
            FileWriter f2 = new FileWriter(studentsDataFilePath, false);
            f2.write(sb.toString());
            f2.close();
        
        } catch (IOException e) {
            e.printStackTrace();
        }   
        
    }

    /**
     * view a particular group's info
     * 
     * @param accessLevel access level of the admin
     * 
     */
    private static void viewAParticularGroup(AccessLevel accessLevel) {
        System.out.println("Enter the school the group belongs to: ");
        String schoolName = IO.nextLine();
        for (int i=0; i<schools.size(); i++) {
            School sch = schools.get(i);
            if (sch.getSchoolName().equalsIgnoreCase(schoolName)) {
                if (accessLevel.hasAccess(schoolName, "read")) {
                    System.out.println("Enter the course ID the group belongs to: ");
                    String courseID = IO.nextLine();
                    List<Course> courses = sch.getAllCourses();
                    for (int j=0; j<courses.size(); j++) {
                        Course c = courses.get(j);
                        if (c.getCourseID().equalsIgnoreCase(courseID)) {
                            System.out.println("Enter the group ID: ");
                            String groupID = IO.nextLine();
                            List<Group> grps = c.getGroups();
                            for (int k=0; k<grps.size(); k++) {
                                Group grp = grps.get(k);
                                if (grp.getGroupID().equalsIgnoreCase(groupID)) {
                                    System.out.println(grp.toString());
                                    return;
                                }
                            }
                            System.out.println("Group was not found in the course.");
                            return;
                        }
                    }
                    System.out.println("The course entered was not found in the school entered!");
                }
                else {
                    System.out.println("You do not have access to view this school!");
                }
                return;
            }
        }
        System.out.println("The school entered does not match any exisiting school.");
    }

    /**
     * View info for a specific course
     * 
     * @param accessLevel access level of the admin
     * 
     */
    private static void viewAParticularCourse(AccessLevel accessLevel) {
        System.out.println("Enter the school the course belongs to: ");
        String schoolName = IO.nextLine();
        for (int i=0; i<schools.size(); i++) {
            School sch = schools.get(i);
            if (sch.getSchoolName().equalsIgnoreCase(schoolName)) {
                if (accessLevel.hasAccess(schoolName, "read")) {
                    System.out.println("Enter the course ID: ");
                    String courseID = IO.nextLine();
                    List<Course> courses = sch.getAllCourses();
                    for (int j=0; j<courses.size(); j++) {
                        Course c = courses.get(j);
                        if (c.getCourseID().equalsIgnoreCase(courseID)) {
                            System.out.println(c.toString());
                            return;
                        }
                    }
                    System.out.println("The course was not found in the school entered!");
                }
                else {
                    System.out.println("You do not have access to view this school!");
                }
                return;
            }
        }
        System.out.println("The school entered does not match any exisiting school.");
    }

    /**
     * View info for a specific school
     * 
     * @param accessLevel access level of the admin
     * 
     */
    private static void viewAParticularSchool(AccessLevel accessLevel) {
        System.out.println("Enter the school you wish to search for: ");
        String schoolName = IO.nextLine();
        int i = 0;
        for (i=0; i<schools.size(); i++) {
            School sch = schools.get(i);
            if (sch.getSchoolName().equalsIgnoreCase(schoolName)) {
                if (accessLevel.hasAccess(schoolName, "read")) {
                    System.out.println(sch.toString());
                }
                else {
                    System.out.println("You do not have permissions to view this school!");
                }
                return;
            }
        }
        System.out.printf("%s not found in the list of schools. \n", schools);
    }

    /**
     * View info for all schools, displays the courses in it
     * 
     * @param accessLevel access level of the admin
     * 
     */
    private static void viewAllSchools(AccessLevel accessLevel) {
        for (School s: schools) {
            if (accessLevel.hasAccess(s.getSchoolName(), "read")) {
                System.out.println(s.toString());
            } else {
                System.out.println("You do not have read access to view the school " + s.getSchoolName() + "!");
            }
        }
        
    }

    /**
     * Create and save a new course 
     * 
     * @param accessLevel access level of the school
     * 
     * @throws IOException
     * 
     */
    private static void addAndSaveCourse(AccessLevel accessLevel) throws IOException {
        System.out.println("Enter the school this course belongs to: ");
        String schoolName = IO.nextLine();
        School school = null;
        for (int i=0; i<schools.size(); i++) {
            if (schools.get(i).getSchoolName().toLowerCase().equalsIgnoreCase(schoolName.toLowerCase())) {
                school = schools.get(i);
                break;
            }
            if (i == schools.size() - 1) {
                System.out.println("Entered school name does not exist.");
                return;
            }
        }
        if ( school != null && accessLevel.hasAccess(schoolName, "write")) {
            
            String courseDataFilePath = "CourseData.txt";
            String groupDataFilePath = "GroupData.txt";
            Course course = school.addACourse();
            if (course == null) {
                return;
            }
            System.out.println("Enter the number of groups to create for this course (1 - 10): ");
            int times = IO.nextInt(1, 10);
            List<Group> groupsCreatedForCourse = new ArrayList<>();
            for (int i=0; i<times; i++) {
                Group group = course.addGroup();
                groupsCreatedForCourse.add(group);

            }
            System.out.println("--- - Displaying all courses in the school ----");
            // for the output feedback
            for (Course c: school.getAllCourses()) {
                System.out.println(c.toString());
            }
            // writes to the course Data file
            StringBuilder sb = new StringBuilder();
            try(BufferedReader br = new BufferedReader(new FileReader(courseDataFilePath))) {
                String line = br.readLine();
                while (line != null) {
                    sb.append(line + "\n");
                    if (line.equalsIgnoreCase("|" + schoolName)) {
                        sb.append(course.toSaveString());
                    }
                    line = br.readLine();
                }
            }
            try {
                FileWriter f2 = new FileWriter(courseDataFilePath, false);
                f2.write(sb.toString());
                f2.close();
            
            } catch (IOException e) {
                e.printStackTrace();
            }   

            // writes to the group data file
            sb = new StringBuilder();
            try(BufferedReader br = new BufferedReader(new FileReader(groupDataFilePath))) {
                String line = br.readLine();
                while (line != null) {
                    sb.append(line + "\n");
                    if (line.equalsIgnoreCase("||" + schoolName)) {
                        sb.append("|" + course.getCourseID() + "\n");
                        sb.append(saveGroupsString(groupsCreatedForCourse));
                    }
                    line = br.readLine();
                }
            }
            try {
                FileWriter f2 = new FileWriter(groupDataFilePath, false);
                f2.write(sb.toString());
                f2.close();
            
            } catch (IOException e) {
                e.printStackTrace();
            } 

        } else {
            System.out.println("You do not have permissions to add courses to this school.");
        }

    }

    /**
     * Helper method to format a list of group to its string representation to be saved
     * @param groupsToFormat a list of group objects to be saved
     * 
     * @return the string representation to be saved
     * 
     */
    private static String saveGroupsString(List<Group> groupsToFormat) {
        StringBuilder sb = new StringBuilder();
        for (Group g: groupsToFormat) {
            sb.append(g.toSaveString());
        }
        return sb.toString();
    }

    /**
     * Creates and saves a student
     * 
     * @param admin admin object for the current session
     * 
     */
    private static void addAndSaveStudent(Admin admin) {
        String sID = null;
        boolean clash = true;
        while (clash) {
            System.out.println("Enter the UID of the new student: ");
            sID = IO.nextLine();
            if (sID.charAt(0) != 'U' || sID.length() != 5) {
                System.out.println("Invalid Format of ID entered. Try again.");
                continue;
            }
            for (int i=0; i<students.size(); i++) {
                Student s = students.get(i);
                if (sID.equalsIgnoreCase(s.getUID())) { // clash
                    System.out.println("Student ID entered is already being used. Try again.");
                    break;
                }
                if (i == students.size() - 1)
                    clash = false;
            }
        }
        System.out.println("Enter first name of new Student: ");
        String firstName = IO.nextLine();
        System.out.println("Enter last name of new Student: ");
        String lastName = IO.nextLine();
        String username = "";
        boolean ok = false;
        while (!ok) {
            System.out.println("Enter a username: ");
            username = IO.nextLine();
            for (int i=0; i<students.size(); i++) {
                Student s = students.get(i);
                if (username.equalsIgnoreCase(s.getUsername())) { // clash
                    System.out.println("Student username entered is already being used. Try again.");
                    ok = false;
                    break;
                }
                if (i == students.size() - 2)
                    ok = true;
            }
        }
        
        System.out.println("Password is defaulted to dummyPass. User is to change them on login.");
        String password = IO.passwordHash("dummyPass");
        System.out.println("Enter student's email: ");
        String email = IO.nextLine();
        System.out.println("Enter student's gender: ");
        String gender = IO.nextLine();
        System.out.println("Enter student's nationality: ");
        String nationality = IO.nextLine();
        System.out.println("Enter student's school: ");
        String school = IO.nextLine();
        boolean adminStatus = false;
        System.out.println("Enter academic year of student: ");
        int yr = IO.nextInt(1, 4);
        
        System.out.println("Enter access start time for student: ");
        LocalDateTime startTime = IO.promptUserLocalDateTime();
        System.out.println("Enter access end time for student: ");
        LocalDateTime endTime = IO.promptUserLocalDateTime();
        while (!startTime.isBefore(endTime)) {
            System.out.println("Invalid entry. End time before start time.");
            System.out.println("Enter access start time for student: ");
            startTime = IO.promptUserLocalDateTime();
            System.out.println("Enter access end time for student: ");
            endTime = IO.promptUserLocalDateTime();
        }
        Student newStudent = new Student(firstName, lastName, sID, username, password, email, gender, nationality, 
        school, adminStatus, yr, startTime, endTime, 0);
        try {
            admin.addStudent(newStudent);
        } catch (IOException e) {
            System.out.println("Error saving new student into the file.");
            e.printStackTrace();
        }
        students.add(newStudent);
        // for output
        for (Student s: students) {
            System.out.println(s.toString());
        }
    }

}