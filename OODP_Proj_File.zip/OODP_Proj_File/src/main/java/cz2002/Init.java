package cz2002;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;

/**
 * This class is concerned with populating the data from text files
 * 
 */
public class Init {
    private static final String schoolsDataFilePath = "SchoolData.txt";
    private static final String courseDataFilePath = "CourseData.txt";
    private static final String groupDataFilePath = "GroupData.txt";
    private static final String studentsDataFilePath = "StudentData.txt";
    private static final String adminsDataFilePath = "AdminData.txt";
    private static final String venueDataFilePath = "VenueData.txt";

    public static List<Admin> initializeAdmins() throws IOException {
        List<Admin> admins = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(adminsDataFilePath))) {
            String line = br.readLine();
            String[] feeder = new String[10];
            int cnt = 0;
            while (line != null) {
                if (cnt > 0 && cnt % 10 == 0) {
                    boolean adminStatus = feeder[9].equalsIgnoreCase("no") ? false: true;
                    
                    Admin admin = new Admin(feeder[1], feeder[2], feeder[0], feeder[3], 
                    feeder[4], feeder[5], feeder[6], feeder[7], feeder[8], adminStatus);
                    admins.add(admin);
                    feeder = new String[13];
                }
                String val = line.split(": ")[1].trim();
                feeder[cnt++ % 10] = val;
                line = br.readLine();
            }
        }
        return admins;
    }

    public static List<Student> initializeStudents() throws IOException {
        List<Student> students = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(studentsDataFilePath))) {
            String line = br.readLine();
            String[] feeder = new String[13];
            int cnt = 0;
            while (line != null) {
                if (cnt > 0 && cnt % 13 == 0) {
                    boolean adminStatus = feeder[9].equalsIgnoreCase("no") ? false: true;
                    int academicYear = Integer.parseInt(feeder[10].split(" ")[1]);
                    LocalDateTime startTimeForAddDrop = feeder[11].equalsIgnoreCase("-") ? null: IO.stringToDateTime(feeder[11]);
                    LocalDateTime endTimeForAddDrop = feeder[12].equalsIgnoreCase("-") ? null: IO.stringToDateTime(feeder[12]);
                    Student s = new Student(feeder[1], feeder[2], feeder[0], feeder[3], 
                    feeder[4], feeder[5], feeder[6], feeder[7], feeder[8], 
                    adminStatus, academicYear, startTimeForAddDrop, endTimeForAddDrop, 0);
                    students.add(s);
                    feeder = new String[13];
                }
                String val = line.split(": ")[1].trim();
                feeder[cnt++ % 13] = val;
                line = br.readLine();
            }
        }
        return students;
    }


    public static List<Venue> initializeVenue() throws IOException {
        List<Venue> venues = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(venueDataFilePath))) {
            String line = br.readLine();
            while (line != null) {
                Venue v = new Venue(line);
                venues.add(v);
                line = br.readLine();
            }
        }
        VenueBookingManager.populateVenues(venues);
        return venues;
    }

    public static List<School> initializeSchools(List<Student> students, List<Venue> venues) throws IOException {
        List<School> schools = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(schoolsDataFilePath))) {
            String schoolName = br.readLine();
            
            while (schoolName != null) { // for every school
                Map<String, Course> schMap = new HashMap<>();
                // open coursesData.txt and look for the right courses for this school
                try(BufferedReader br2 = new BufferedReader(new FileReader(courseDataFilePath))) {
                    String line = br2.readLine();
                    boolean buildCourse = false;
                    int courseFeederIdx = 0;
                    String[] courseFeeder = new String[13];
                    String val;
                    while (line != null) { // match the line with |schoolName, then start populating information for the course
                        if (line.charAt(0) == '|') {
                            if (buildCourse) {
                                break; // we are looking at another school already
                            }
                                
                            if (line.equalsIgnoreCase("|" + schoolName)) {
                                buildCourse = true;
                            }
                            
                        } else if (buildCourse) {
                            if (line.charAt(0) == '-') {
                                val = line.substring(1, line.length());
                                courseFeederIdx = 0;
                            } else {
                                val = line.split(": ")[1];
                            }
                            courseFeeder[courseFeederIdx++] = val;
                            if (courseFeederIdx == 13) { // we can start building the groups for this course
                                Map<String, Group> groups = new HashMap<>();
                                for (String grpIdx: courseFeeder[courseFeederIdx-1].split(", ")) {
                                    Group grp = buildGroup(schoolName, courseFeeder[0], grpIdx, students, venues, Integer.valueOf(courseFeeder[2]));
                                    groups.put(grp.getGroupID(), grp);
                                }
                                Map<String, Map<String, Integer>> guidelines = buildSchedule(courseFeeder);
                                Schedule schedule = new Schedule(courseFeeder[0], guidelines);
                                Course course = new Course(courseFeeder[0], courseFeeder[1], Integer.valueOf(courseFeeder[2]), schoolName, schedule, groups);
                                schMap.put(course.getCourseID(), course);
                                courseFeederIdx = 0;
                            }
                        }
                        line = br2.readLine();
                    }
                }
                School sch = new School(schoolName, schMap);
                schools.add(sch);
                
                schoolName = br.readLine();
            }
        }
        return schools;
    }


    public static Group buildGroup(String schoolName, String courseID, String groupID, List<Student> students, List<Venue> venues, int au)
            throws IOException {
        Group group = null;
        try(BufferedReader br = new BufferedReader(new FileReader(groupDataFilePath))) {
            String line = br.readLine();
            boolean foundSchool = false, foundCourse = false, foundGroup = false;
            while (line != null) {
                if (line.equalsIgnoreCase("||" + schoolName))
                    foundSchool = true;
                else if (foundSchool && line.equalsIgnoreCase("|" + courseID))
                    foundCourse = true;
                else if (foundCourse && line.equalsIgnoreCase("--" + groupID.trim())) {
                    foundGroup = true;
                }
                
                else if (foundSchool && foundGroup && foundCourse) {
                    String[] studentsEnrolledID = line.split(": ")[1].split(" ");
                    line = br.readLine();
                    String[] studentsWaitListedID = line.split(": ")[1].split(" ");
                    line = br.readLine();
                    int slots = Integer.parseInt(line.split(": ")[1].trim());

                    // building map for timetable
                    String[] timetableFeeder = new String[15];
                    for (int i=0; i<15; i++) {
                        String val;
                        if (i % 5 == 0) {
                            val = br.readLine();
                            val = val.substring(2, val.length());
                        }
                        else
                            val = br.readLine();
                        timetableFeeder[i] = val;
                    }
                    Map<String, Map<String, String>> mappedTimetable = buildMappedTimetable(timetableFeeder, venues);
                    Timetable timetable = new Timetable(groupID, courseID, mappedTimetable);
                    List<Student> studentsEnrolledObj = new ArrayList<>();
                    for (int i=0; i<studentsEnrolledID.length; i++) {
                        for (int j=0; j<students.size(); j++) {
                            if (studentsEnrolledID[i].equalsIgnoreCase(students.get(j).getUID())) {
                                Student anEnrolledStudent = students.get(j);
                                
                                studentsEnrolledObj.add(anEnrolledStudent);
                                break;
                            }
                        }
                    }
                    EnrolledList studentsEnrolled = new EnrolledList(courseID, groupID, studentsEnrolledObj);

                    LinkedList<Student> studentsWaitListedObj = new LinkedList<>();
                    for (int i=0; i<studentsWaitListedID.length; i++) {
                        for (int j=0; j<students.size(); j++) {
                            if (studentsWaitListedID[i].equalsIgnoreCase(students.get(j).getUID())) {
                                studentsWaitListedObj.add(students.get(j));
                                break;
                            }
                        }
                    }
                    WaitList studentsWaitListed = new WaitList(courseID, groupID, studentsWaitListedObj);
                    
                    group = new Group(courseID, groupID, schoolName, studentsEnrolled, studentsWaitListed, slots, timetable);
                    // we can also populate the student's enrolled course and waitlist reference here
                    for (Student s: studentsEnrolledObj) {
                        List<Group> oldGrps = s.getGroups();
                        oldGrps.add(group);
                        s.setGroups(oldGrps);
                        int oldAU = s.getAU();
                        oldAU += au;
                        s.setAU(oldAU);
                    }
                    for (Student s: studentsWaitListedObj) {
                        List<Group> oldWait = s.getWaitlists();
                        oldWait.add(group);
                        s.setWaitLists(oldWait);
                        int oldAU = s.getAU();
                        oldAU += au;
                        s.setAU(oldAU);
                    }

                    return group;
                }
                line = br.readLine();
            }
        }
        return group;
    }

    /*
        {
            "tut": {
                "weeks": "1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13",
                "day": "Monday"
                "time": "11:30 - 12:30",
                "venue": "TR+18"
            }, 
            "labs": {
                "weeks": "1, 3, 5, 7, 9, 11, 13",
                "day": "Tuesday",
                "time": "12:30 - 14:30",
                "venue": "HWLAB3"
            },
            "lect" : {
                ...
            }
        }
    */
    public static Map<String, Map<String, String>> buildMappedTimetable(String[] timetableFeeder, List<Venue> venues) {
        Map<String, Map<String, String>> mappedTimetable = new HashMap<>();
        for (int i=0; i<3; i++) {
            Map<String, String> map = new HashMap<>();
            for (int j=0; j<4; j++) {
                String[] pair = timetableFeeder[5*i + j + 1].split(": ");
                map.put(pair[0], pair[1]);
                
            }
            // book the venues
            for (int k=0; k<venues.size(); k++) {
                Venue v = venues.get(k);
                if (v.getVenueName().equalsIgnoreCase(map.get("venue"))) {
                    for (String wk: map.get("weeks").split(", ")) {
                        String day = map.get("day");
                        day = day.startsWith("Thu") ? day.toLowerCase().substring(0, 4): day.toLowerCase().substring(0, 3);
                        v.bookVenue("week"+wk, day, map.get("time"), timetableFeeder[0] + " - " + timetableFeeder[i*5]);
                    }
                    break;
                }
            }
            mappedTimetable.put(timetableFeeder[i*5], map);
        }
        return mappedTimetable;
    }

    /*
        {
            "tut": {
                "numSessions": 8
                "duration": 1
                "freq": 1
            },
            "lab": {

            },
            "lect": {

            }
        }

    */
    public static Map<String, Map<String, Integer>> buildSchedule(String[] courseFeeder) {
        String[] acts = new String[] {"tut", "lab", "lect"};
        Map<String, Map<String, Integer>> guidelines = new HashMap<>();
        for(int i=0; i<acts.length; i++) {
            Map<String, Integer> map = new HashMap<>();
            for (int j=0; j<3; j++) {
                String key;
                switch (j) {
                    case 0:
                        key = "numSessions";
                        break;
                    case 1:
                        key = "duration";
                        break;
                    case 2:
                        key = "freq";
                        break;
                    default:
                        key = null;
                }
                map.put(key, Integer.parseInt(courseFeeder[i+j+3]));
            }
            guidelines.put(acts[i], map);
        }
        return guidelines;
    }
}
