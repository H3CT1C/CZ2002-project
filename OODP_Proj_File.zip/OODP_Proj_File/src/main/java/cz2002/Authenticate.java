package cz2002;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * Handles authentication of users logging in
 */
public class Authenticate {

    /**
     * Login to the student portal 
     * 
     * @param students a list of students to check against
     * @return the authenticated user
     */
    public static User loginStudentPortal(List<Student> students) {
        System.out.println("Enter username: ");
        String username = IO.nextLine();
        System.out.println("Enter password: ");
        String password = IO.nextSecret();
        password = IO.passwordHash(password); // hash the password
        System.out.println();
        for (int i=0; i<students.size(); i++) {
            User s = students.get(i);
            if (s.getUsername().equalsIgnoreCase(username) && s.getPassword().trim().equalsIgnoreCase(password.trim())) {
                Student student = (Student) s;
                // check if student has access allowed via start and end
                LocalDateTime now = LocalDateTime.now(ZoneId.of("Asia/Singapore"));
                LocalDateTime startTimeAllowed = student.getStartTimeForAddDrop();
                LocalDateTime endTimeAllowed = student.getEndTimeForAddDrop();
                if (endTimeAllowed != null && startTimeAllowed != null && now.isBefore(endTimeAllowed) && now.isAfter(startTimeAllowed)) {
                    System.out.println("Welcome " + s.getFirstName());
                    return s;
                } else {
                    System.out.println("You are not allowed to enter into STARS now.");
                    System.out.println("Your allocated time slot is " + 
                        IO.dateTimeToString(startTimeAllowed) + " - " + IO.dateTimeToString(endTimeAllowed)
                    );
                    return null;
                }
            }
                
        }
        return null;
    }

    /**
     * logins via admin portal
     * 
     * @param admins a list of admins to check against
     * @return the authenticated user
     */
    public static User loginAdminPortal(List<Admin> admins) {
        System.out.println("Enter username: ");
        String username = IO.nextLine();
        System.out.println("Enter password: ");
        String password = IO.nextSecret();
        for (int i=0; i<admins.size(); i++) {
            User s = admins.get(i);
            if (s.getUsername().equalsIgnoreCase(username) && s.getPassword().equalsIgnoreCase(password)) {
                System.out.println("Welcome " + s.getFirstName());
                return s;
            }
               
        }
        return null;
    }
}
