package cz2002;

import java.util.HashMap;
import java.util.Map;

public class Venue {
    private String venueName;
    /*
    Each venue has 13 weeks for academic booking
    Each week has 5 rows, Mon-Fri
    Each day has an array of size 48, of 30 min time slices to represent 24 hours
    example: 
    {
        "week1": {
            "mon": [], size 48, index 0 => 00:00-00:30, 1 => 00:30-01:00
            "tue": [],
            "wed": [],
            "thur": [],
            "fri", []
        },
        "week2": {
            ...
        },
        ...
    }

    */
    private Map<String, Map<String, String[]>> bookingMap;

    public Venue(String venueName) {
        this.venueName = venueName;
        bookingMap = initializeBookingMap();
    }

    /* checks if the venue is available for booking at the requested week, day, time
     * @params: weekReq, string representation of the week requested, eg: "week1"
     * @params: dayReq, string rep of day requested, eg: "mon"
     * @params: timeReq, string rep of time requested, eg: "11:30 - 12:30"
     * 
     * @return: boolean as to whether this venue is free at that time
    */
    public boolean checkAvailable(String weekReq, String dayReq, String timeReq) {
        int[] idxs = IO.getTimeSliceIndexes(timeReq);
        // get the respective array for the right day, in the right week
        String[] dayArray = bookingMap.get(weekReq).get(dayReq);
        for (int i=idxs[0]; i<idxs[1]; i++) {
            if (dayArray[i] != null)
                return false;
        }
        return true;
    }

    /* books the venue at the requested week, day, time
     * Note: this method does not check if there are clashes it simply overwrites
     * @params: weekReq, string representation of the week requested, eg: "week1"
     * @params: dayReq, string rep of day requested, eg: "mon"
     * @params: timeReq, string rep of time requested, eg: "11:30 - 12:30"
     * @params: reason, the reason for booking, eg: "CZ2002 SSP3"
     * 
    */
    public void bookVenue(String weekReq, String dayReq, String timeReq, String reason) {
        int[] idxs = IO.getTimeSliceIndexes(timeReq);
        String[] dayArray = bookingMap.get(weekReq).get(dayReq);
        for (int i=idxs[0]; i<idxs[1]; i++) {
            dayArray[i] = reason;
        }
        
    }

    /* empties the venue at the requested week, day, time
     * Note: this method does not check if there are any existing bookings it simply overwrites
     * @params: weekReq, string representation of the week requested, eg: "week1"
     * @params: dayReq, string rep of day requested, eg: "mon"
     * @params: timeReq, string rep of time requested, eg: "11:30 - 12:30"
     * 
    */
    public void cancelBooking(String weekReq, String dayReq, String timeReq) {
        int[] idxs = IO.getTimeSliceIndexes(timeReq);
        String[] dayArray = bookingMap.get(weekReq).get(dayReq);
        for (int i=idxs[0]; i<idxs[1]; i++) {
            dayArray[i] = null;
        }
    }

    public String getVenueName() {
        return venueName;
    }


    // returns an empty booking map, ready for use
    private Map<String, Map<String, String[]>> initializeBookingMap() {
        Map<String, Map<String, String[]>> newBookingMap = new HashMap<>();
        String[] monToFri = new String[] {
            "mon", "tue", "wed", "thur", "fri"
        };
        for (int i=1; i<16; i++) {
            String weekString = "week" + i;
            Map<String, String[]> monToFriMap = new HashMap<>();
            // build an array of size 48 for each day
            for (String day: monToFri) {
                String[] dayArray = new String[48];
                monToFriMap.put(day, dayArray);
            }
            newBookingMap.put(weekString, monToFriMap);
        }
        return newBookingMap;
    }
}
