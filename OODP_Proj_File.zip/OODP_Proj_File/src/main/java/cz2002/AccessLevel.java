package cz2002;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Handles authorization on a school level
 */
public class AccessLevel {

	private static final String schoolsDataFilePath = "SchoolData.txt";

	private boolean adminStatus;
	private String schoolName;
	/**
	 * Each School is tied to a list of Read, Write and Execute boolean variables, all lower case keys
	 * example: { { "scse": [], "eee": [], "mae": [] } }
	 * 
	 */
	private Map<String, Boolean[]> permissionsMap;

	public AccessLevel(String schoolName, boolean adminStatus) {
		this.schoolName = schoolName;
		this.adminStatus = adminStatus;

		try {
			permissionsMap = initializePermissionsMap();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Returns a boolean checking if a user has requested access for a school
	 * 
	 * @param schoolName2 the schoolName to match
	 * @param permissionReq the type of permissions requested: read, write, execute
	 * 
	 * @return boolean whether the user has requested permissions for the school
	 * 
	 */ 
	public boolean hasAccess(String schoolName2, String permissionReq) 
	{
		schoolName2 = schoolName2.toLowerCase();
		int idx;
		Boolean[] permArr = permissionsMap.getOrDefault(schoolName2, null);
		if (permArr != null) {
			switch (permissionReq.toLowerCase()) {
				// if the user wishes to read
				case ("read"):
					idx = 0;
					break;
				// if the user wishes to write
				case ("write"):
					idx = 1;
					break;
				// if the user wishes to execute
				case ("execute"):
					idx = 2;
					break;
				default:
					idx = -1;
			}
			if (idx != -1)
				return permArr[idx];
		}
		return false;
	}

	private Map<String, Boolean[]> initializePermissionsMap() throws IOException {
		List<String> schools = new ArrayList<>();
		try(BufferedReader br = new BufferedReader(new FileReader(schoolsDataFilePath))) {
            String line = br.readLine();
            while (line != null) {
                schools.add(line);
                line = br.readLine();
            }
        }
		Map<String, Boolean[]> schoolsMap = new HashMap<>();
		// build an array size 10 for each school that will house the Read, Write and Execute values
		for (String sch : schools) {
			Boolean[] permissionsArray = new Boolean[3];
			// default permissions
			permissionsArray[0] = true;
			permissionsArray[1] = false;
			permissionsArray[2] = true;
			if(this.adminStatus && this.schoolName.equalsIgnoreCase(sch)) {
				permissionsArray[1] = true;
				}
				schoolsMap.put(sch.toLowerCase(), permissionsArray);
			}

		return schoolsMap;
	}

}

