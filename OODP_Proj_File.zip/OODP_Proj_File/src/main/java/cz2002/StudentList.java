package cz2002;

public interface StudentList {
    public Student removeStudentByID(String id);

    public void addStudent(Student student);

    public int getSize();

    public String toString();
}
