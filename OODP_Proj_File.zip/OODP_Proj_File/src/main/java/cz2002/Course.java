package cz2002;

import javax.print.attribute.standard.DateTimeAtCompleted;
import java.time.LocalDateTime;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Course object, has a reference to the groups in it
 * 
 */
public class Course {
    //initiailizing attributes
	private Map<String, Group> groups;
    private String courseID;
    private String courseName;
    private Schedule schedule;
    private String schoolName;
    private int au;
    
    /**
     * Main constructor for course, with predefined groups and a schedule 
     * 
     * @param courseID id of the course
     * @param courseName name of the course
     * @param au number of aus for this course
     * @param schoolName school name the course belongs to
     * @param schedule schedule of the course
     * @param groups the groups in this course
     */
    public Course(String courseID,String courseName, int au, String schoolName, Schedule schedule, Map<String, Group> groups) {
        
        this.groups = groups;
        this.courseID = courseID.trim();
        this.courseName = courseName.trim();
        this.schedule = schedule;
        this.schoolName = schoolName;
        this.au = au;
    }

    /**
     * Secondary constructor for course for undefined schedule and groups
     * 
     * @param courseID id of the course
     * @param courseName name of the course
     * @param au number of aus for this course
     * @param schoolName school name the course belongs to
     */
    public Course(String courseID,String courseName, int au, String schoolName) {
        this.courseID = courseID.trim();
        
        this.courseName = courseName;
        this.schedule = new Schedule(courseID);
        this.schoolName = schoolName;
        this.groups = new HashMap<>();
        this.au = au;
    }

    /**
     * find a specific group via the group id
     * 
     * @param groupID string for the group id
     * 
     * @return the group object found, returns null if does not exist
     */
    public Group findGroup(String groupID) {
    	
    	 if (groups.containsKey(groupID.toUpperCase())) {
             return groups.get(groupID);
         } 
    	 else {
             System.out.printf("Failed to retrieve group. Group ID: %s does not exist in course %s. \n", groupID, this.courseName);
             return null;
         }
    	 
    }

    /**
     * Adds a group into the course
     * 
     * @return the group being added, null if unsuccessfull
     */
    public Group addGroup() {
        System.out.println("Enter the ID of the new group:");
    	String newGroup = IO.nextLine();
        if (groups.containsKey(newGroup)) {
            System.out.printf("Failed to add group. Group ID: %s already exists in course %s. \n", newGroup, this.courseName);
        } else {
            
            Map<String, Map<String, String>> mappedTimetable = this.schedule.buildTimetable(newGroup);
            Group group = new Group(courseID, newGroup, schoolName, mappedTimetable);
            groups.put(newGroup, group);
            System.out.printf("Added group %s into course %s successfully. \n", newGroup, this.courseName);
            return group;
        }
        return null;
    }

    /**
     * Removes a group from the course
     * @param deletegroup group id to delete
     */
    public void deleteGroup(String deletegroup){
    	if (groups.containsKey(deletegroup)) {
             groups.remove(deletegroup);
             System.out.printf("Group %s successfully removed from course %s. \n", deletegroup, this.courseName);
         } else {
             System.out.printf("Failed to remove group. Group ID: %s does not exist in course %s. \n", deletegroup, this.courseName);
         }
    }

    public int getAU() {
        return au;
    }

    public void setAU(int newAU) {
        au = newAU;
    }

   
    public String getCourseID() {
        return this.courseID;
    }

    public void setCourseID(String newcourseID) {
        this.courseID = newcourseID;
    }

    /**
     * Get the number of slots of a group in the course
     * 
     * @param groupID group id to find
     * 
     * @return the number of slots in that group, returns -1 if not found
     * 
     */
    public int getSlotsByIndex(String groupID){
        
        if(groups.containsKey(groupID)) {
            return groups.get(groupID).getVacancies();
        }
        else {
            return -1;
        }
    }

    // change slots by group index
    /**
     * Change the slot for a group in this course
     * @param groupID the string id of the group
     * @param vacancy the number of vacancies to set
     * 
     */
    public void changeSlotsByIndex(String groupID,int vacancy){
        if (groups.containsKey(groupID)) {
            groups.get(groupID).setSlots(vacancy);
            System.out.println("Successfully updated vacancy.");
        }
        else {
            System.out.println("No groupID found, no update done.");
        }
    }

    public String getCourseName() {
        return this.courseName;
    }

    public void setCourseName(String newcourseName) {
        this.courseName = newcourseName;
    }

    /**
     * 
     * @return the list of string for group ids in the course
     */
    public List<String> getAllGroupsID() {
        List<String> groupIDs = new ArrayList<>();
        
        for (Group group: groups.values()) {
            groupIDs.add(group.getGroupID());
        }
        
        return groupIDs;
    }

    /**
     * 
     * @return the list of group objects in the course
     */
    public List<Group> getGroups() {
        List<Group> grps = new ArrayList<>();
        for (Group grp: groups.values()) {
            grps.add(grp);
        }
        return grps;
    }

    public int getTotalSlots() {
        int slots = 0;
        for (Group group: groups.values()) {
            slots += group.getSlots();
        }
        return slots;
    }

    public int getVacancies() {
        int vacancies = 0;
        for (Group group: groups.values()) {
            vacancies += group.getVacancies();
        }
        return vacancies;
    }

    /**
     * Return a string to format a course for display
     */
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-- - Course Details for " + courseID + " are as follows: -- - \n");
        sb.append("Course name: " + courseName + "\n");
        sb.append("School: " + schoolName + "\n");
        sb.append("AU: " + au + "\n");
        sb.append("Groups: ");
        for (String idx: getAllGroupsID()) {
            sb.append(idx + " ");
        }
        sb.append("\n");
        sb.append("Total Slots: " + getTotalSlots() + "\n");
        sb.append("Vacancies left: " + getVacancies() + "\n");
        sb.append(schedule.toString());
        sb.append("\n");
        return sb.toString();
    }

    /**
     * Return a string to save in the data file
     * 
     * @return the string that is formatted to be saved
     */
    public String toSaveString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-" + courseID + "\n");
        sb.append("CourseName: " + courseName + " \n");
        sb.append("AU: " + au + "\n");
        sb.append("TutSessions: " + schedule.getNumTutorials() + "\n");
        sb.append("TutDuration: " + schedule.getDurationOfTut() + "\n");
        sb.append("TutFreq: " + schedule.getFrequencyOfTut() + "\n" );
        sb.append("LabSessions: " + schedule.getNumLabs() + "\n");
        sb.append("LabDuration: " + schedule.getDurationOfLab() + "\n");
        sb.append("LabFreq: " + schedule.getFrequencyOfLabs() + "\n");
        sb.append("LectSessions: " + schedule.getNumLects() + "\n");
        sb.append("LectDuration: " + schedule.getDurationOfLects() + "\n");
        sb.append("LectFreq: " + schedule.getFrequencyOfLects() + "\n");
        StringBuilder groupsIndexes = new StringBuilder();
        List<Group> grps = getGroups();
        for (int i=0; i<grps.size(); i++) {
            Group grp = grps.get(i);
            groupsIndexes.append(grp.getGroupID());
            if (i != groups.size() - 1) {
                groupsIndexes.append(", ");
            }
        }
        sb.append("Groups: " + groupsIndexes.toString() + " \n");
        return sb.toString();
    }
}
