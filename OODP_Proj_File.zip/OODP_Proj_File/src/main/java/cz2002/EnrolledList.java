package cz2002;

import java.util.ArrayList;
import java.util.List;

public class EnrolledList implements StudentList, NotificationInterface {

    private List<Student> studentsEnrolled;
    private String courseID;
    private String groupID;

    /**
     * Main constructor to create a new list using defined students
     * 
     * @param courseID course id this list belongs to
     * @param groupID group id this list belongs to
     * @param studentsEnrolled a list of students to be added
     * 
     */
    public EnrolledList(String courseID, String groupID, List<Student> studentsEnrolled) {
        this.courseID = courseID;
        this.groupID = groupID;
        this.studentsEnrolled = studentsEnrolled;
    }

    /**
     * Secondary constructor to create a new list without predefined students
     * 
     * @param courseID course id this list belongs to
     * @param groupID group id this list belongs to
     * 
     */
    public EnrolledList(String courseID, String groupID) {
        studentsEnrolled = new ArrayList<>();
        this.courseID = courseID;
        this.groupID = groupID;
    }
    

    /**
     * Remove a student by the id passed in
     * 
     * @param id id of the student to be removed
     * 
     */
	@Override
	public Student removeStudentByID(String id) {
		for (int i=0; i<studentsEnrolled.size(); i++) {
            Student student = studentsEnrolled.get(i);
            if (student.getUID().equalsIgnoreCase(id)) {
                studentsEnrolled.remove(i);
                notifyStudentRemove(student);
                return student;
            }
        }
		return null;
	}

    /**
     * Add a student into the enrolled list
     * 
     * @param student student object to be added
     * 
     */
	@Override
	public void addStudent(Student student) {
        studentsEnrolled.add(student);
        notifyStudentAdd(student);
    }
    
    /**
     * Calls the email service to notify a student via the student's email
     * 
     * @param student student object to be notified
     * 
     */
    @Override
	public void notifyStudentAdd(Student student) {
        String title = String.format("Notification for enrollment into %s %s", courseID, groupID);
		String message = String.format(
        "Dear %s, \n" +
        "This is a confirmation email that you have enrolled into %s %s. \n" +
        "Thank you. This is an automated email, do not reply.", student.getFirstName(), this.courseID, this.groupID);
        EmailService.sendMail(student.getEmail(), title, message);
		
	}

    /**
     * Notify a student for removal
     * 
     * @param student student object to be notified
     * 
     */
	@Override
	public void notifyStudentRemove(Student student) {
        String title = String.format("Notification for removal from %s %s", courseID, groupID);
		String message = String.format(
        "Dear %s, \n" +
        "This is a confirmation email that you have unenrolled from %s %s. \n" +
        "Thank you. This is an automated email, do not reply.", student.getFirstName(), this.courseID, this.groupID);
        EmailService.sendMail(student.getEmail(), title, message);
		
    }
    
    @Override
    public int getSize() {
        return studentsEnrolled.size();
    }

    /**
     * formats a string representation of enrolled list to be displayed
     * 
     */
    @Override
    public String toString() {
        StringBuilder displayString = new StringBuilder();
        if (studentsEnrolled.isEmpty()) {
            displayString.append("Empty list. \n");
        }
        for (int i=0; i<studentsEnrolled.size(); i++) {
            displayString.append(studentsEnrolled.get(i).toString() + "\n");
        }
        return displayString.toString();
    }

    /**
     * Get a list of student object enrolled in the list
     *
     * @return a list of student objects enrolled
     */
    public List<Student> getAllStudents() {
        return studentsEnrolled;
    }
}
