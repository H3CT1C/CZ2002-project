package cz2002;

import java.util.*;
import java.time.LocalDateTime;

public class Student extends User{
	private List<Group> groups;
	private List<Group> waitlists;
	private int academicYear;
	private LocalDateTime startTimeForAddDrop;
	private LocalDateTime endTimeForAddDrop;
	private int au;
	
	public Student(String firstName, String lastName, String UID, String username, 
	String password, String email, String gender, String nationality, String school, 
	boolean adminStatus, int academicYear, LocalDateTime startTimeForAddDrop, LocalDateTime endTimeForAddDrop, int au) 
	{
		super(firstName, lastName, UID, username, password, email, gender, nationality, school, adminStatus);
		groups = new ArrayList<Group>();
		waitlists = new ArrayList<Group>();
		this.academicYear = academicYear;
		this.startTimeForAddDrop = startTimeForAddDrop;
		this.endTimeForAddDrop = endTimeForAddDrop;
		this.au = au;
	}

	// secondary constructor for  -  start and end time for add drop
	public Student(String firstName, String lastName, String UID, String username, 
	String password, String email, String gender, String nationality, String school, 
	boolean adminStatus, int academicYear, int au) 
	{
		super(firstName, lastName, UID, username, password, email, gender, nationality, school, adminStatus);
		groups = new ArrayList<Group>();
		waitlists = new ArrayList<Group>();
		this.academicYear = academicYear;
		this.startTimeForAddDrop = null;
		this.endTimeForAddDrop = null;
		this.au = au;
	}
	
	public Student() {
		super();
	}

	public int getAU() {
		return au;
	}

	public void setAU(int a) {
		this.au = a;
	}
	
	/**
	 *checks the list of groups in its groups list to see if it is already inside
	 * 
	 *@param g2 the Group that is checked against all the groups currently enrolled
	 *
	 *@return returns true if the course is not present, else it will return false
	 *
	 */
	public boolean canEnroll(Group g2) {
		for (Group g: groups) {
			if (g.getCourseID().equals(g2.getCourseID())) {
				System.out.println("Already enrolled in this course.");
				return false;
			}
		}
		for (Group g: waitlists) {
			if (g.getCourseID().equals(g2.getCourseID())) {
				System.out.println("Already in wait list for this course.");
				return false;
			}
		}

		return true;
	}

	public boolean dropCourse(Group group) {
		if (this.groups.contains(group)) {
			this.groups.remove(group);
			return true; //removes group and returns true
		}
		else {
			return false; //if group is not present in arraylist
		}
	}
	
	public boolean dropWaitlist(Group group) {
		if (this.waitlists.contains(group)) {
			this.waitlists.remove(group);
			return true; //removes group and returns true
		}
		else {
			return false; //if group is not present in arraylist
		}
	}
	
	
	public List<Group> getGroups() {
		return groups;
	}

	public void setGroups(List<Group> updatedGroups) {
		groups = updatedGroups;
	}
	
	public List<Group> getWaitlists() {
		return waitlists;
	}

	public void setWaitLists(List<Group> updatedWaitLists) {
		waitlists = updatedWaitLists;
	}

	
	public int getAcademicYear() {
		return academicYear;
	}
	
	public void printCoursesRegistered() {
		for (int i = 0; i < groups.size(); i++) {
			System.out.print(groups.get(i).getCourseID());
		}
	}
	
	public boolean changeIndex() {
		return true;// not sure what to do here
	}
	
	public void setAcademicYear(int admissionYr) {
		if (academicYear == admissionYr){
			System.out.printf("Admission Year is already set to %d. \n", admissionYr);
		}
		else {
			academicYear = admissionYr;
		}
	}
	
	public void setAddDropTime(LocalDateTime startTime, LocalDateTime endTime) {
		this.startTimeForAddDrop = startTime;
		this.endTimeForAddDrop = endTime;
	}
	
	public boolean checkCourses(String chk) {
		for(int i=0; i<this.getGroups().size();i++) {
			if(this.getGroups().get(i).getCourseID().equalsIgnoreCase(chk)) {
				return true;
				//returns true if in the course list
			}
		}
		return false;
	}
	
	public boolean checkWaitlist(String chk) {
		for(int i=0; i<this.getWaitlists().size();i++) {
			if(this.getWaitlists().get(i).getCourseID().equalsIgnoreCase(chk)) {
				return true;
				//returns true if in the waitlist
			}
		}
		return false;
	}


	// get start time for add drop
    public LocalDateTime getStartTimeForAddDrop() {
        return this.startTimeForAddDrop;
    }

    // set start time for add drop
    public void setStartTimeForAddDrop(LocalDateTime startTime) {
        this.startTimeForAddDrop = startTime;
    }

    // get end time for add drop
    public LocalDateTime getEndTimeForAddDrop() {
        return this.endTimeForAddDrop;
    }


    // set end time for add drop
    public void setEndTimeForAddDrop(LocalDateTime endTime) {
        this.endTimeForAddDrop = endTime;
	}

	// formats the student's info to be displayed
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("-- - Student's data as follows: ---\n");
		sb.append("Student ID: " + getUID() + "\n");
		sb.append("First name: " + getFirstName() + "\n");
		sb.append("Last name: " + getLastName() + "\n");
		sb.append("Email: " + getEmail() + "\n");
		sb.append("Gender: " + getGender() + "\n");
		sb.append("Nationality: " + getNationality() + "\n");
		sb.append("School: " + getSchool() + "\n");
		sb.append("Academic Year: " + getAcademicYear() + "\n");
		sb.append("Access period: " + getStartTimeForAddDrop() + " - " + getEndTimeForAddDrop() + "\n");
		sb.append("Groups enrolled: \n");
		for (Group g: groups) {
			sb.append(g.getCourseID() + " " + g.getGroupID() + "\n");
		}
		sb.append("Groups waitlisted: \n");
		for (Group g: waitlists) {
			sb.append(g.getCourseID() + " " + g.getGroupID() + "\n");
		}
		return sb.toString();
	}

	public String toSaveString() {
		StringBuilder sb = new StringBuilder();
		sb.append("UID: " + getUID() + "\n");
		sb.append("Firstname: " + getFirstName() + "\n");
		sb.append("Lastname: " + getLastName() + "\n");
		sb.append("Username: " + getUsername() + "\n");
		sb.append("Password: " + getPassword() + "\n");
		sb.append("Email: " + getEmail() + "\n");
		sb.append("Gender: " + getGender() + "\n");
		sb.append("Nationality: " + getNationality() + "\n");
		sb.append("School: " + getSchool() + "\n");
		String status = isAdmin() ? "yes": "no";
		sb.append("Admin: " + status + "\n");
		sb.append("AcademicYr: " + "Year " + getAcademicYear() + "\n");
		sb.append("StartAdd: " + IO.dateTimeToString(getStartTimeForAddDrop()) + "\n");
		sb.append("EndAdd: " + IO.dateTimeToString(getEndTimeForAddDrop()) + "\n");
		return sb.toString();
	}
}
