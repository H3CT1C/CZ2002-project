package cz2002;

import java.rmi.server.UID;

public class User {
	
	private String firstName;
	private String lastName;
	private String UID;
	private String username;
	private String password;
	private String email;
	private String gender;
	private String nationality;
	private String school;
	private boolean adminStatus;
	private AccessLevel accessLevel;
	
	public User(String firstName, String lastName, String UID, String username, String password, String email, String gender, String nationality, String school, boolean adminStatus) {
		this.firstName=firstName;
		this.lastName=lastName;
		this.UID=UID;
		this.username=username;
		this.password=password;
		this.email=email;
		this.gender=gender;
		this.nationality=nationality;
		this.school=school;
		this.adminStatus=adminStatus;
		// on runtime, build the access level
		this.accessLevel = new AccessLevel(school, adminStatus);
	}
	
	public User() {
	}

	public AccessLevel getAccessLevel() {
		return accessLevel;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getUID() {
		return UID;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public String getEmail() {
		return email;	
	}
	
	public String getGender() {
		return gender;
	}
	
	public String getNationality() {
		return nationality;
	}
	
	public String getSchool() {
		return school;
	}
	
	public boolean setFirstName(String fn) {
		if (firstName.equals(fn)){
			return false;
		}
		else {
			firstName = fn;
			return true;
		}
	}
	
	public boolean setLastName(String ln) {
		if (lastName.equals(ln)){
			return false;
		}
		else {
			lastName = ln;
			return true;
		}
	}
	
	public boolean setUsername(String un) {
		if (username.equals(un)){
			return false;
		}
		else {
			username = un;
			return true;
		}
	}
	
	public boolean setPassword(String pw) {
		if (password.equals(pw)){
			return false;
		}
		else {
			password = pw;
			return true;
		}
	}
	
	public boolean setEmail(String em) {
		if (email.equals(em)){
			return false;
		}
		else {
			email = em;
			return true;
		}
	}
	
	public boolean setGender(String gen) {
		if (gender.equals(gen)){
			return false;
		}
		else {
			gender = gen;
			return true;
		}
	}
	
	public boolean setNationality(String nl) {
		if (nationality.equals(nl)){
			return false;
		}
		else {
			nationality = nl;
			return true;
		}
	}
	
	public boolean setSchool(String sch) {
		if (school.equals(sch)){
			return false;
		}
		else {
			school = sch;
			return true;
		}
	}
	
	public boolean isAdmin() {
		return adminStatus;
	}
	
	public boolean isEqual(User other) {
		return other.UID.equals(UID);
	}
}
