package cz2002;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * A class to handle firing of emails
 * 
 */
public class EmailService extends Thread {
	private String targetMail;
	private String title;
	private String messageText;

	public static void sendMail(String targetMail, String title, String message) {
		EmailService t1 = new EmailService(targetMail, title, message);
		t1.start();
	}

	public EmailService(String targetMail, String title, String message) {
		this.targetMail = targetMail;
		this.title = title;
		this.messageText = message;
	}

	/**
	 * 
	 * Fires an email in a new thread, response from this call is not waited for
	 * 
	 * @throws MessagingException if failed to send email
	 */
	@Override
	public void run() {
		final String username = "cz2002.stars.notif@gmail.com"; // to be added
		final String password = "DuMMYPASSWORD"; // to be added

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("cz2002.stars.notif@gmail.com"));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(this.targetMail)); // to be added an email addr
			message.setSubject(this.title);
			message.setText(this.messageText);

			Transport.send(message);

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
}