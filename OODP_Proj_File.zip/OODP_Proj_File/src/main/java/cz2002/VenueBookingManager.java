package cz2002;

import java.util.List;

public class VenueBookingManager {

    private static List<Venue> venues;

    public static void populateVenues(List<Venue> v) {
        venues = v;
    }

    /**
     *books a venue
     * Note: this method does not check if there are clashes it simply overwrites
     * @param weekReq, string representation of the first week requested, eg: "week1"
     * @param dayReq, string rep of day requested, eg: "mon"
     * @param timeReq, string rep of time requested, eg: "11:30 - 12:30"
     * @param reason, the reason for booking, eg: "CZ2002 SSP3"
     * @param numSessions, the number of sessions
     * @param freq, the weekly frequency, 1 or 2 every weeks
     * 
     * @return String the name of the venue successfully booked
     */ 
    public static String bookVenue(String weekReq, String dayReq, String timeReq, String reason, int numSessions, int freq) {
        System.out.println("Booking a venue...");
        Venue venueSelected = null;
        boolean success = false;
        while (!success) {
            System.out.println("Select a venue to book from the list below:");
            for (int i=0; i<venues.size(); i++) {
                System.out.printf("%d. %s \n", i+1, venues.get(i).getVenueName());
            }
            int choice = IO.nextInt(1, venues.size());
            venueSelected = venues.get(choice - 1);
            int i = 0;
            for (i=0; i<numSessions; i+= freq) {
                String weekReqTemp = weekReq.substring(0, weekReq.length()-1) + (Character.getNumericValue(weekReq.charAt(weekReq.length() - 1)) + i);
                if (venueSelected.checkAvailable(weekReqTemp, dayReq, timeReq)) {
                    success = true;
                } else {
                    success = false;
                    System.out.println("Venue is already booked at the requested time slot. Select another venue.");
                    break;
                }
            }
        }
        for (int i=0; i<numSessions; i+= freq) {
            String weekReqTemp = weekReq.substring(0, weekReq.length()-1) + (Character.getNumericValue(weekReq.charAt(weekReq.length() - 1)) + i);
            venueSelected.bookVenue(weekReqTemp, dayReq, timeReq, reason);
        }
        return venueSelected.getVenueName();
    }

    /**
     * removes the booking at the requested times
     * @param weekReq, string representation of the first week requested, eg: "week1"
     * @param dayReq, string rep of day requested, eg: "mon"
     * @param timeReq, string rep of time requested, eg: "11:30 - 12:30"
     * @param numSessions, the number of sessions
     * @param freq, the weekly frequency, 1 or 2 every weeks
     * @param venueName, name of the venue to modify its time slots
     */
    public void cancelBooking(String weekReq, String dayReq, String timeReq, int numSessions, int freq, String venueName) {
        Venue venue = getVenueByName(venueName);
        if (venue != null) {
            System.out.printf("Freed up %s's time slot for the requested timings. \n", venueName);
            for (int i=0; i<numSessions; i+= freq) {
                String weekReqTemp = weekReq.substring(0, weekReq.length()-1) + Character.getNumericValue(weekReq.charAt(weekReq.length() - 1)) + i;
                venue.cancelBooking(weekReqTemp, dayReq, timeReq);
            }
        } else {
            System.out.println("Invalid venue name requested.");
        }
    }

    // gets the venue object by name, returns null if does not exist
    private Venue getVenueByName(String venueName) {
        for (int i=0; i<venues.size(); i++) {
            if (venues.get(i).getVenueName().equalsIgnoreCase(venueName))
                return venues.get(i);
        }
        return null;
    }
}
